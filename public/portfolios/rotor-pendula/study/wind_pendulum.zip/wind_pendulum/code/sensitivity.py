"""Two perturbation sizes from one explicitly saved state, 400 periods each."""
import sys,json
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'code'))
from compute import Parameters,benettin
r=json.loads((ROOT/'data/runs/robust_chaotic_long.json').read_text());z=np.load(ROOT/'data/runs/robust_chaotic_long.npz')
p=Parameters(**r['parameters']);x=np.r_[z['q'][-1],z['u'][-1]].astype(float);s0=2*np.pi*(r['discard_periods']+r['average_periods'])
out=dict(start_state=x.tolist(),start_phase_s=s0,state_source='explicit float32 checkpoint cast to float64; identical state and forcing phase for both perturbation sizes',results=[])
for eps in [1e-6,1e-7]:
 b=benettin(p,x,s0,periods=400,eps=eps);out['results'].append({k:v for k,v in b.items() if k!='poincare'})
 print(eps,b['lambda_dimensionless'],b['blocks'],flush=True)
(ROOT/'data/epsilon_sensitivity.json').write_text(json.dumps(out,indent=2))
