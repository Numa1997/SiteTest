"""Select compact trajectories, inventory every file, make and verify one ZIP."""
from pathlib import Path
import csv,zipfile,json,hashlib
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
# Only the two long runs in Figure 6 are needed for offline regeneration of every figure.
KEEP={'robust_regular_long.npz','robust_chaotic_long.npz'}
for p in (ROOT/'data/runs').glob('*.npz'):
 if p.name not in KEEP:p.unlink()
for p in ROOT.rglob('*'):
 if p.is_file() and (p.suffix in ['.pyc','.so','.aux','.log','.out'] or '__pycache__' in p.parts):p.unlink()
for p in (ROOT/'data/runs').glob('*.npz'):
 z=np.load(p)
 assert all(z[k].dtype==np.float32 for k in z.files)
 r=json.loads(p.with_suffix('.json').read_text())
 assert (len(z['t'])-1)/r['average_periods']<=32
with (ROOT/'data/summary.csv').open() as f:
 rows=list(csv.DictReader(f))
 required={'study','Omega_rad_s','r_p_m','R_rotor_m','m1_kg','m2_kg','l1_m','l2_m','c_N_m_s_per_rad','mean_power_W','rotor_power_W','energy_balance_rel_err','lyapunov_1_per_s','regime','source'}
 assert required.issubset(rows[0]);assert len(rows)==160
 assert all(r['regime']=='not measured' for r in rows if r['lyapunov_1_per_s']=='nan')
 from math import isfinite
 assert all(float(r['r_p_m'])<=float(r['R_rotor_m']) for r in rows if r['study']=='corrected_mapping')
inv=ROOT/'FILE_INVENTORY.csv';inv.touch()
for _ in range(5):
 files=sorted(p for p in ROOT.rglob('*') if p.is_file())
 with inv.open('w') as f:
  w=csv.writer(f);w.writerow(['path','bytes']);w.writerows((p.relative_to(ROOT).as_posix(),p.stat().st_size) for p in files)
total=sum(p.stat().st_size for p in files)
assert total<8_000_000,('uncompressed total',total)
output=ROOT.parent/'wind_pendulum_complete.zip'
with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files:z.write(p,'wind_pendulum/'+p.relative_to(ROOT).as_posix())
assert output.stat().st_size<8_000_000
with zipfile.ZipFile(output) as z:assert z.testzip() is None
print(json.dumps(dict(file=str(output.resolve()),files=len(files),uncompressed_bytes=total,zip_bytes=output.stat().st_size,limit_bytes=8_000_000,CRC='passed',sha256=hashlib.sha256(output.read_bytes()).hexdigest()),indent=2))
