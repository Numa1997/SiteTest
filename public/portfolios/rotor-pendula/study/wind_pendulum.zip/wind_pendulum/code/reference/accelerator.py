"""Optional compiled stage kernel; scipy.solve_ivp and DOP853 remain the solver.
Set PENDULUM_NATIVE=0 for unmodified SciPy. Native use is opt-in via environment.
No files in SciPy are edited. Each process registers a local DOP853 subclass.
A C compiler is needed only for the acceleration, not for reproducibility.
"""
import os
from pathlib import Path

def enable():
    if os.environ.get('PENDULUM_NATIVE','0')!='1':return
    import ctypes,subprocess
    import numpy as np
    from scipy.integrate._ivp.rk import DOP853
    from scipy.integrate._ivp.ivp import METHODS
    path=Path(__file__).resolve().parent;src=path/'dop853_kernel.c';lib=path/'dop853_kernel.so'
    if not lib.exists() or lib.stat().st_mtime<src.stat().st_mtime:
        # Compile locally; no package installation or network access.
        temp=path/f'dop853_kernel.{os.getpid()}.so'
        subprocess.run(['gcc','-O3','-fPIC','-shared','-ffp-contract=off',str(src),'-lm','-o',str(temp)],check=True)
        os.replace(temp,lib)
    kernel=ctypes.CDLL(str(lib)).dopstep
    arr=ctypes.c_void_p
    kernel.argtypes=[ctypes.c_int,arr,ctypes.c_double,arr,arr]+[ctypes.c_double]*6+[arr]*10
    kernel.restype=ctypes.c_int
    class AcceleratedDOP853(DOP853):
        def __init__(self,fun,*args,**kwargs):
            owner=getattr(fun,'__self__',None)
            self.native_parameters=None
            if owner is not None and hasattr(owner,'nd') and fun.__name__ in ('rhs','rhs4','rhs8'):
                p=owner.p
                self.native_parameters=np.array([*owner.nd,p.M*p.L*p.L*p.Omega*p.Omega,float(p.single)],dtype=float)
            super().__init__(fun,*args,**kwargs)
            if self.native_parameters is not None:
                self.native_atol=np.full(self.n,self.atol) if np.ndim(self.atol)==0 else np.asarray(self.atol)
                self.native_A=np.ascontiguousarray(self.A);self.native_B=np.ascontiguousarray(self.B);self.native_C=np.ascontiguousarray(self.C)
                self.native_E3=np.ascontiguousarray(self.E3);self.native_E5=np.ascontiguousarray(self.E5)
                self.native_ptrs=tuple(a.ctypes.data for a in [self.native_atol,self.native_A,self.native_B,self.native_C,self.native_E3,self.native_E5])
                self.native_par_ptr=self.native_parameters.ctypes.data
                self.native_K_ptr=self.K.ctypes.data
        def _step_impl(self):
            if self.native_parameters is None:return super()._step_impl()
            yn=np.empty_like(self.y);fn=np.empty_like(self.y);out=np.empty(4)
            mn=10*abs(np.nextafter(self.t,self.direction*np.inf)-self.t)
            status=kernel(self.n,self.native_par_ptr,self.t,self.y.ctypes.data,self.f.ctypes.data,self.h_abs,self.t_bound,self.direction,mn,self.max_step,float(self.rtol),*self.native_ptrs,yn.ctypes.data,fn.ctypes.data,self.native_K_ptr,out.ctypes.data)
            if status:return False,'Native DOP853 stage kernel failed: '+str(status)
            self.h_previous=out[2];self.y_old=self.y;self.t=out[0];self.y=yn;self.h_abs=out[1];self.f=fn;self.nfev+=int(out[3])
            return True,None
    METHODS['DOP853']=AcceleratedDOP853
