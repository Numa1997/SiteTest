"""Longer averaging, alternate basin checks and Benettin epsilon sensitivity.
Run after all chaos rows have a measured Lyapunov exponent.
"""
from pathlib import Path
import json,argparse
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
from model import Parameters
from study import worker,assemble
from lyapunov import benettin,task
ROOT=Path(__file__).resolve().parents[1]

def run_job(job):
    r=worker(job);r=task(ROOT/'data/runs'/f'{r["name"]}.json');return r

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--workers',type=int,default=4);args=ap.parse_args()
    rows=assemble();chaotic=sorted([r for r in rows if r['study']=='chaos' and r['regime']=='chaotic'],key=lambda r:r['P_hat'],reverse=True)
    for ch in chaotic:
        matched=[r for r in rows if r['study']=='chaos' and r['regime']=='regular' and r['R']==ch['R'] and r['G']==ch['G']]
        if matched:reg=max(matched,key=lambda r:r['P_hat']);break
    else:raise RuntimeError('No matched chaotic/regular pair')
    jobs=[]
    for label,r in [('chaotic',ch),('regular',reg)]:
        p=Parameters(**r['parameters'])
        jobs.append((f'robust_{label}_long','robustness',p,400,800,np.array([1.2,-.8,0.,0.])))
        for j,x0 in enumerate([np.array([.03,-.02,0.,0.]),np.array([2.4,.7,-.5,.3])]):
            jobs.append((f'robust_{label}_basin{j}','robustness',p,400,400,x0))
    results=[]
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for f in as_completed([pool.submit(run_job,j) for j in jobs]):
            r=f.result();results.append(r);print(r['name'],r['mean_power_W'],r['regime'],flush=True)
    # Perturbation-size check on the long chaotic trajectory (same phase and state).
    p=Parameters(**ch['parameters']);z=np.load(ROOT/'data/runs/robust_chaotic_long.npz')
    x0=np.array([z[k][-1] for k in ['q1','q2','u1','u2']]);s0=float(z['t'][-1]*p.Omega)
    checks=[]
    for eps in [1e-6,1e-7]:
        r=benettin(p,x0,s0,periods=400,eps=eps)
        checks.append({k:v for k,v in r.items() if k!='poincare'});print('epsilon',eps,'lambda/Omega',r['lambda_dimensionless'],flush=True)
    (ROOT/'data/robustness.json').write_text(json.dumps(dict(chaotic_source=ch['name'],regular_source=reg['name'],epsilon_checks=checks,run_names=[r['name'] for r in results]),indent=2));assemble()
