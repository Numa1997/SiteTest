"""Check exact dimensionless similarity using a second SI mapping."""
from pathlib import Path
import json
from dataclasses import replace
import numpy as np
from model import Parameters
from study import worker,assemble
ROOT=Path(__file__).resolve().parents[1]
r=json.loads((ROOT/'data/runs/small_o0_r0_both_c1.json').read_text());p=Parameters(**r['parameters'])
# M x3, L x4, Omega /2, rp x4 -> c x24, power x6.
p2=replace(p,Omega=p.Omega/2,rp=p.rp*4,m1=p.m1*3,m2=p.m2*3,l1=p.l1*4,l2=p.l2*4,c=p.c*24)
r2=worker(('similarity_scaled','similarity',p2,100,200,None))
a=np.load(ROOT/'data/runs/small_o0_r0_both_c1.npz');b=np.load(ROOT/'data/runs/similarity_scaled.npz')
err=max(float(np.max(abs(a[k]-b[k]))) for k in ['q1','q2','u1','u2'])
res=dict(power_scale_ratio=r2['mean_power_W']/r['mean_power_W'],predicted_power_scale=6.,dimensionless_trajectory_max_difference=err)
(ROOT/'data/similarity.json').write_text(json.dumps(res,indent=2));assemble();print(res)
