"""Independent checks: static energy, analytic linear solution, RK4 convergence."""
from pathlib import Path
import json, argparse
import numpy as np
from scipy.integrate import solve_ivp
from scipy.linalg import eig
from model import System,Parameters,G,RTOL,ATOL,integrate,save_run
ROOT=Path(__file__).resolve().parents[1]

def static_checks():
    al=.5;be=.5;b=.5;A=al*al;B=be*b*b;D=be*al*b
    mass=np.array([[A,D],[D,B]]); K=np.diag([al,be*b])
    freqs=np.sqrt(np.linalg.eigvals(np.linalg.solve(mass,K)))
    slow=2*np.pi/min(freqs);fast=2*np.pi/max(freqs)
    def rhs(c):
        def fun(t,x):
            q1,q2,v1,v2=x; h=D*np.cos(q1-q2); si=np.sin(q1-q2)
            f1=-D*si*v2*v2-al*np.sin(q1)-2*c*v1+c*v2
            f2=D*si*v1*v1-be*b*np.sin(q2)-c*(v2-v1)
            det=A*B-h*h
            return [v1,v2,(B*f1-h*f2)/det,(A*f2-h*f1)/det]
        return fun
    def energy(y):
        q1,q2,v1,v2=y
        return .5*A*v1*v1+.5*B*v2*v2+D*np.cos(q1-q2)*v1*v2+2*al*np.sin(q1/2)**2+2*be*b*np.sin(q2/2)**2
    ts=np.linspace(0,1000*slow,40001)
    sol=solve_ivp(rhs(0),[0,ts[-1]],[.2,.1,0,0],t_eval=ts,method='DOP853',rtol=RTOL,atol=ATOL,max_step=fast/40)
    E=energy(sol.y);err=(E-E[0])/E[0]
    # Unit mapping is only for required .npz SI arrays, M=.1 kg,L=.2 m.
    L=.2;M=.1;tg=np.sqrt(L/G)
    np.savez_compressed(ROOT/'data/runs/check_energy.npz',t=ts*tg,theta1=sol.y[0]-np.pi/2,theta2=sol.y[1]-np.pi/2,omega1=sol.y[2]/tg,omega2=sol.y[3]/tg,P_harvest=np.zeros(len(ts)),tau_on_rotor=np.zeros(len(ts)),Omega=0.,rp=0.,m1=.05,m2=.05,l1=.1,l2=.1,c=0.,g=G,energy_rel_error=err,gravitational_time=ts,slow_period=slow)
    c=.1;C=c*np.array([[2,-1],[-1,1]])
    J=np.block([[np.zeros((2,2)),np.eye(2)],[-np.linalg.solve(mass,K),-np.linalg.solve(mass,C)]])
    vals,V=eig(J);x0=np.array([1e-5,-.5e-5,0,0]);coeff=np.linalg.solve(V,x0)
    ts2=np.linspace(0,20*slow,2001)
    analytic=np.real(V@(coeff[:,None]*np.exp(vals[:,None]*ts2)))
    sol2=solve_ivp(rhs(c),[0,ts2[-1]],x0,t_eval=ts2,method='DOP853',rtol=RTOL,atol=ATOL,max_step=fast/40)
    diff=sol2.y-analytic
    np.savez_compressed(ROOT/'data/runs/check_linear.npz',t=ts2*tg,theta1=sol2.y[0]-np.pi/2,theta2=sol2.y[1]-np.pi/2,omega1=sol2.y[2]/tg,omega2=sol2.y[3]/tg,P_harvest=c*M*L*L/tg*((sol2.y[2]/tg)**2+((sol2.y[3]-sol2.y[2])/tg)**2),tau_on_rotor=np.zeros(len(ts2)),Omega=0.,rp=0.,m1=.05,m2=.05,l1=.1,l2=.1,c=c*M*L*L/tg,g=G,analytic=analytic,numerical=sol2.y,gravitational_time=ts2)
    out=dict(energy_max_relative=float(max(abs(err))),energy_periods=1000,energy_slow_period_dimensionless=float(slow),energy_max_step_dimensionless=float(fast/40),linear_max_abs_error=float(np.max(abs(diff))),linear_relative_to_initial=float(np.max(abs(diff))/np.max(abs(x0))),linear_initial_amplitude=1e-5,linear_damping_dimensionless=c)
    assert out['energy_max_relative']<1e-9
    (ROOT/'data/validation.json').write_text(json.dumps(out,indent=2));print(out,flush=True)

def rk4(name,steps):
    z=np.load(ROOT/'data/runs'/f'{name}.npz');p=Parameters(**{k:z[k].item() for k in Parameters.__dataclass_fields__})
    sys=System(p);y=np.array([z['q1'][0],z['q2'][0],z['u1'][0],z['u2'][0],0.,0.])
    s=float(z['t'][0]*p.Omega);s0=s;h=2*np.pi/steps;n=int(z['average_periods'])*steps
    # Independent fixed-step RK4 quadrature includes work and harvest states.
    block=[];lastH=0.
    for i in range(n):
        k1=sys.rhs(s,y);k2=sys.rhs(s+h/2,y+h*k1/2);k3=sys.rhs(s+h/2,y+h*k2/2);k4=sys.rhs(s+h,y+h*k3)
        y+=h*(k1+2*k2+2*k3+k4)/6;s=s0+(i+1)*h
        if (i+1)%(50*steps)==0:
            block.append((y[4]-lastH)/(50*2*np.pi/p.Omega));lastH=y[4]
    duration=(s-s0)/p.Omega
    return dict(name=name,steps_per_period=steps,mean_power_W=float(y[4]/duration),rotor_power_W=float(y[5]/duration),end_state=y[:4].tolist(),block_power_W=block)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--rk4',nargs='*');args=ap.parse_args()
    if args.rk4 is None:static_checks()
    else:
        out=json.loads((ROOT/'data/rk4.json').read_text()) if (ROOT/'data/rk4.json').exists() else []
        for name in args.rk4:
            for n in [2048,4096]:
                if any(r['name']==name and r['steps_per_period']==n for r in out):continue
                r=rk4(name,n);out.append(r);print(r,flush=True)
        (ROOT/'data/rk4.json').write_text(json.dumps(out,indent=2))
