"""Planar turbine-mounted pendula. Angles from inertial +x, CCW positive.
All numerical values SI. State x=(q1,q2,u1,u2), q=theta-Omega*t,
u=(omega-Omega)/Omega. Independent variable s=Omega*t.
"""
from dataclasses import dataclass, asdict
import numpy as np
import math
from scipy.integrate import solve_ivp

RTOL=1e-10
ATOL=1e-12
G=9.80665

@dataclass
class Parameters:
    Omega: float=20.943951023931955
    rp: float=1.0
    m1: float=0.05
    m2: float=0.05
    l1: float=0.1
    l2: float=0.1
    c: float=0.01
    mode: str='both'
    single: bool=False
    g: float=G
    @property
    def M(self): return self.m1+self.m2
    @property
    def L(self): return self.l1+self.l2
    @property
    def c0(self): return self.c if self.mode in ('both','pivot') else 0.0
    @property
    def c1(self): return self.c if self.mode in ('both','middle') else 0.0

class System:
    def __init__(self,p):
        self.p=p
        self.A=p.M*p.l1**2
        self.B=p.m2*p.l2**2
        self.D=p.m2*p.l1*p.l2
        al=p.l1/p.L; be=p.m2/p.M; b=1-al
        self.nd=(al,be,b,al*al,be*b*b,be*al*b,p.rp/p.L,p.g/(p.Omega*p.Omega*p.L),p.c0/(p.M*p.L*p.L*p.Omega),p.c1/(p.M*p.L*p.L*p.Omega))
    def acceleration(self,s,x):
        p=self.p
        q1,q2,u1,u2=x[:4]
        # Fully dimensionless dynamics: no dimensional coefficients below.
        alpha,beta,b,A,B,D,R,G,k0,k1=self.nd
        sin,cos=(np.sin,np.cos) if np.ndim(s)>0 else (math.sin,math.cos)
        if p.single:
            z=-R*sin(q1)-G*cos(s+q1)-k0*u1
            return z,z
        d=q1-q2; h=D*cos(d)
        f1=-D*sin(d)*(1+u2)**2-alpha*(R*sin(q1)+G*cos(s+q1))-k0*u1+k1*(u2-u1)
        f2= D*sin(d)*(1+u1)**2-beta*b*(R*sin(q2)+G*cos(s+q2))-k1*(u2-u1)
        det=A*B-h*h
        return (B*f1-h*f2)/det,(A*f2-h*f1)/det
    def rhs4(self,s,x):
        a,b=self.acceleration(s,x)
        return np.array([x[2],x[3],a,b])
    def rhs8(self,s,x):
        return np.r_[self.rhs4(s,x[:4]),self.rhs4(s,x[4:])]
    def observables(self,s,x,accel=None):
        """Power and torque from independent Newton-force reconstruction."""
        p=self.p; O=p.Omega
        q1,q2,u1,u2=x[:4]
        a1,a2=self.acceleration(s,x) if accel is None else accel; a1=a1*O*O; a2=a2*O*O
        sin,cos=(np.sin,np.cos) if np.ndim(s)>0 else (math.sin,math.cos)
        w1=O*(1+u1); w2=O*(1+u2)
        if p.single:
            crossF=p.M*p.L*(a1*cos(q1)-w1*w1*sin(q1))+p.M*p.g*cos(s)
            power=p.c0*(O*u1)**2
        else:
            crossF=p.M*p.l1*(a1*cos(q1)-w1*w1*sin(q1))+p.m2*p.l2*(a2*cos(q2)-w2*w2*sin(q2))+p.M*p.g*cos(s)
            power=p.c0*(O*u1)**2+p.c1*(O*(u2-u1))**2
        tau=-p.rp*crossF+p.c0*O*u1
        return power,tau
    def rhs(self,s,x):
        a,b=self.acceleration(s,x)
        power,tau=self.observables(s,x,(a,b))
        return np.array([x[2],x[3],a,b,power/self.p.Omega,-tau])
    def energy(self,s,x):
        p=self.p; O=p.Omega
        q1,q2,u1,u2=x[:4]
        w1=O*(1+u1); w2=O*(1+u2)
        if p.single:
            return .5*p.M*((O*p.rp)**2+(p.L*w1)**2+2*O*p.rp*p.L*w1*np.cos(q1))+p.M*p.g*(p.rp*np.sin(s)+p.L*np.sin(s+q1))
        T=.5*p.M*(O*p.rp)**2+.5*self.A*w1*w1+.5*self.B*w2*w2+self.D*np.cos(q1-q2)*w1*w2+O*p.rp*(p.M*p.l1*w1*np.cos(q1)+p.m2*p.l2*w2*np.cos(q2))
        V=p.g*(p.M*p.rp*np.sin(s)+p.M*p.l1*np.sin(s+q1)+p.m2*p.l2*np.sin(s+q2))
        return T+V

def integrate(p,discard=100,periods=200,x0=None,samples=32,max_step=.20):
    sys=System(p)
    if x0 is None: x0=np.array([0.03,-0.02,0.,0.])
    if p.single: x0=np.array([x0[0],x0[0],x0[2],x0[2]])
    s0=discard*2*np.pi; s1=(discard+periods)*2*np.pi
    sol0=solve_ivp(sys.rhs4,[0,s0],x0,method='DOP853',rtol=RTOL,atol=ATOL,max_step=max_step)
    if not sol0.success: raise RuntimeError(sol0.message)
    y0=np.r_[sol0.y[:,-1],0.,0.]
    grid=np.linspace(s0,s1,periods*samples+1)
    sol=solve_ivp(sys.rhs,[s0,s1],y0,method='DOP853',rtol=RTOL,atol=ATOL,max_step=max_step,t_eval=grid)
    if not sol.success: raise RuntimeError(sol.message)
    y=sol.y; dt=(s1-s0)/p.Omega
    H=y[4,-1]; W=y[5,-1]
    deltaE=sys.energy(s1,y[:,-1])-sys.energy(s0,y[:,0])
    residual=(W-H-deltaE)/max(abs(H),1e-30)
    power,tau=sys.observables(grid,y)
    block=np.diff(y[4,::50*samples])/(50*2*np.pi/p.Omega)
    return dict(p=p,s=grid,y=y,power=power,tau=tau,mean_power=H/dt,rotor_power=W/dt,balance=abs(residual),signed_balance=residual,storage_rate=deltaE/dt,blocks=block,nfev=sol.nfev+sol0.nfev,discard=discard,periods=periods,x0=np.asarray(x0))

def linear_power(p):
    """First order in g/(Omega^2 rp), about radial q=0."""
    O=p.Omega
    if p.single:
        K=p.M*p.L*p.rp*O*O
        amp=-p.M*p.L*p.g/(K-p.M*p.L*p.L*O*O+1j*O*p.c0)
        return .5*p.c0*O*O*abs(amp)**2
    A=p.M*p.l1**2; B=p.m2*p.l2**2; D=p.m2*p.l1*p.l2
    mass=np.array([[A,D],[D,B]])
    K=O*O*np.array([[p.M*p.l1*p.rp+D,-D],[-D,p.m2*p.l2*p.rp+D]])
    C=np.array([[p.c0+p.c1,-p.c1],[-p.c1,p.c1]])
    f=-p.g*np.array([p.M*p.l1,p.m2*p.l2])
    amp=np.linalg.solve(K-O*O*mass+1j*O*C,f)
    return .5*O*O*np.real(amp.conj()@C@amp)

def save_run(path,r,extra=None):
    p=r['p']; s=r['s']; y=r['y']; O=p.Omega
    fields=dict(t=s/O,theta1=s+y[0],theta2=s+y[1],omega1=O*(1+y[2]),omega2=O*(1+y[3]),P_harvest=r['power'],tau_on_rotor=r['tau'],q1=y[0],q2=y[1],u1=y[2],u2=y[3],harvest_integral=y[4],rotor_work_integral=y[5],discard_periods=r['discard'],average_periods=r['periods'],x0=r['x0'])
    fields.update(asdict(p))
    if extra: fields.update(extra)
    np.savez_compressed(path,**fields)

# Optional local stage-kernel acceleration. The default remains unmodified SciPy.
from accelerator import enable as _enable_accelerator
_enable_accelerator()
