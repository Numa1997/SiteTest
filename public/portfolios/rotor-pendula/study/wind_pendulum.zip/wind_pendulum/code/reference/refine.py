"""Refine damping on a periodic branch, then verify with 100+200 periods.
The shooting objective is a periodic-orbit integral, not a shortened transient
average. Every reported optimum is subsequently a full long-run simulation.
"""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
from pathlib import Path
import json,argparse
from dataclasses import replace
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import root,minimize_scalar
from model import Parameters,System,RTOL,ATOL
from study import worker,assemble
ROOT=Path(__file__).resolve().parents[1]

def refine_group(metas):
    best=max(metas,key=lambda z:z['mean_power_W']);p=Parameters(**best['parameters']);name=best['name'].rsplit('_c',1)[0]+'_opt'
    out=ROOT/'data/runs'/f'{name}.json'
    if out.exists():return json.loads(out.read_text())
    z=np.load(ROOT/'data/runs'/f'{best["name"]}.npz');x0=np.array([z[k][-1] for k in ['q1','q2','u1','u2']]);x0[:2]=(x0[:2]+np.pi)%(2*np.pi)-np.pi
    stride=(len(z['t'])-1)//int(z['average_periods'])
    winding=np.r_[np.round((np.array([z['q1'][-1],z['q2'][-1]])-np.array([z['q1'][-1-stride],z['q2'][-1-stride]]))/(2*np.pi))*2*np.pi,0.,0.]
    history=[]
    def objective(logc):
        c=float(np.exp(logc));sys=System(replace(p,c=c))
        def endpoint(x):
            rr=solve_ivp(sys.rhs4,[0,2*np.pi],x,method='DOP853',rtol=RTOL,atol=ATOL,max_step=.2)
            return rr.y[:,-1]
        def residual(x):return endpoint(x)-x-winding
        if p.single:
            unpack=lambda v:np.array([v[0],v[0],v[1],v[1]])
            sol=root(lambda v:residual(unpack(v))[[0,2]],x0[[0,2]],tol=2e-9)
            sol.x=unpack(sol.x)
        else: sol=root(residual,x0,tol=2e-9)
        error=float(np.max(abs(residual(sol.x))))
        if error>1e-7: return 1e6+error
        rr=solve_ivp(sys.rhs,[0,2*np.pi],np.r_[sol.x,0,0],method='DOP853',rtol=RTOL,atol=ATOL,max_step=.2)
        P=float(rr.y[4,-1]*p.Omega/(2*np.pi));history.append([c,P,error]);return -P
    # A local branch maximum, deliberately not advertised as a global optimum.
    opt=minimize_scalar(objective,bounds=(np.log(p.c/2),np.log(p.c*2)),method='bounded',options={'xatol':.01,'maxiter':16})
    rr=worker((name,best['study']+'_opt',replace(p,c=float(np.exp(opt.x))),100,200,None))
    rr.update(optimization_history=history,shooting_winding_angles=winding[:2].tolist(),optimization_logc_tolerance=.01,optimization_success=bool(opt.success),optimization_bracket=[p.c/2,p.c*2],optimization_method='periodic shooting, then full 100+200 period verification')
    out.write_text(json.dumps(rr,indent=2));return rr

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--workers',type=int,default=4);args=ap.parse_args()
    metas=[json.loads(f.read_text()) for f in (ROOT/'data/runs').glob('*.json')]
    groups={}
    for r in metas:
        if r['study'] in ['small','large','universal','damping']:
            groups.setdefault(r['name'].rsplit('_c',1)[0],[]).append(r)
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        fs=[pool.submit(refine_group,v) for v in groups.values()]
        for f in as_completed(fs):
            r=f.result();print(r['name'],r['mean_power_W'],r['c_N_m_s_per_rad'],flush=True)
    assemble()
