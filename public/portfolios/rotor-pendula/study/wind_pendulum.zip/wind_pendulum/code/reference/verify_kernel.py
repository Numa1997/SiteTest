"""Cross-check optional kernel against an archived unmodified-SciPy full run."""
import os
os.environ['PENDULUM_NATIVE']='1'
from pathlib import Path
import json,time
import numpy as np
from model import Parameters,integrate
ROOT=Path(__file__).resolve().parents[1]
r0=json.loads((ROOT/'data/runs/small_o0_r0_both_c1.json').read_text())
p=Parameters(**r0['parameters']);start=time.time();r=integrate(p)
z=np.load(ROOT/'data/runs/small_o0_r0_both_c1.npz')
res=dict(power_relative_difference=float(r['mean_power']/r0['mean_power_W']-1),balance=float(r['balance']),max_state_difference=max(float(np.max(abs(r['y'][i]-z[k]))) for i,k in enumerate(['q1','q2','u1','u2'])),elapsed_s=time.time()-start,nfev=r['nfev'])
assert abs(res['power_relative_difference'])<1e-9
assert res['max_state_difference']<1e-8
(ROOT/'data/native_validation.json').write_text(json.dumps(res,indent=2));print(res)
