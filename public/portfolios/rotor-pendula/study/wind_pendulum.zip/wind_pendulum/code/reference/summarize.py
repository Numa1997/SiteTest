"""Write report fragments directly from computed results; no hand-entered powers."""
from pathlib import Path
import json
import numpy as np
from study import assemble
ROOT=Path(__file__).resolve().parents[1];DATA=ROOT/'data'
rows=assemble();by={r['name']:r for r in rows}

def texnum(v,n=4):
    if not np.isfinite(v):return r'\text{not evaluated}'
    if v==0:return '0'
    if .001<=abs(v)<10000:return f'{v:.{n}g}'
    m,e=f'{v:.{n-1}e}'.split('e');return m+r'\times10^{'+str(int(e))+'}'

def fnum(v,unit='',n=4):return '$'+texnum(v,n)+(r'\ \mathrm{'+unit+'}' if unit else '')+'$'
def put(name,text):(DATA/(name+'.tex')).write_text(text+'\n')

def best(study):
    out={}
    for r in rows:
        if r['study'] not in (study,study+'_opt'):continue
        key=(r['R'],r['G'],r['mu'],r['lambda_ratio'],r['generator_mode'],r['single'])
        if key not in out or r['mean_power_W']>out[key]['mean_power_W']:out[key]=r
    return list(out.values())

chaotic=[r for r in rows if r['study']=='chaos' and r['regime']=='chaotic']
if not chaotic:raise RuntimeError('No confirmed chaos yet: do not invent a chaotic comparison')
# Select strongest chaotic point that has a matched regular damping competitor.
chaotic=sorted(chaotic,key=lambda r:r['P_hat'],reverse=True)
for ch in chaotic:
    matched=[r for r in rows if r['study']=='chaos' and r['R']==ch['R'] and r['G']==ch['G'] and r['regime']=='regular']
    if matched:reg=max(matched,key=lambda r:r['P_hat']);break
else:raise RuntimeError('No matched regular comparator')
regglobal=max([r for r in rows if r['study']=='chaos' and r['regime']=='regular'],key=lambda r:r['P_hat'])
(DATA/'selection.json').write_text(json.dumps(dict(chaotic=ch['name'],regular_matched=reg['name'],regular_global=regglobal['name']),indent=2))

phys=best('small')+best('large');single=[r for r in phys if r['single']];doub=[r for r in phys if not r['single'] and r['generator_mode']=='both'];top=max(single+doub,key=lambda r:r['mean_power_W'])
ratios=[]
for d in doub:
    s=next(r for r in single if r['Omega_rad_s']==d['Omega_rad_s'] and r['r_p_m']==d['r_p_m']);ratios.append(d['mean_power_W']/s['mean_power_W'])
put('abstract_results',r'\C In the selected turbine mappings, the equal-mass, equal-reach single pendulum exceeds the equal-mass double pendulum with both generators: the double/single power ratio ranges from '+fnum(min(ratios))+' to '+fnum(max(ratios))+r'. The best mapped ideal harvest is '+fnum(top['mean_power_W'],'W')+r' for the illustrative mass and length stated later. The chaotic/regular comparison and its search limits are quantified below. \A The appropriate potential use is a local sensor supply, not additional net turbine generation.')

v=json.loads((DATA/'validation.json').read_text());rk=json.loads((DATA/'rk4.json').read_text())
text=r'\C The maximum conservative energy drift is '+fnum(v['energy_max_relative'])+r', below the required $10^{-9}$. The small-angle analytic test has maximum dimensionless state error '+fnum(v['linear_max_abs_error'])+r', or '+fnum(v['linear_relative_to_initial'])+r' relative to the initial amplitude. These are measured maxima over the sampled validation trajectories.'+'\n\n'
text+=r'\C Fixed-step RK4 independently integrates the same force and generator model over the full 200-period averaging interval, starting at the saved post-transient state. Results are:'+'\n'+r'\begin{center}\small\begin{tabular}{lrrrr}\toprule Case & Steps/period & RK4 power (W) & Relative difference & End-state error\\\midrule'+'\n'
for rr in rk:
    ref=by[rr['name']];z=np.load(DATA/'runs'/f'{rr["name"]}.npz');end=np.array([z[k][-1] for k in ['q1','q2','u1','u2']]);err=float(np.max(abs(np.array(rr['end_state'])-end)))
    text+=('Small double' if 'both' in rr['name'] else 'Small single')+' & '+str(rr['steps_per_period'])+' & $'+texnum(rr['mean_power_W'])+'$ & $'+texnum(abs(rr['mean_power_W']/ref['mean_power_W']-1))+'$ & $'+texnum(err)+'$ '+chr(92)*2+'\n'
text+=r'\bottomrule\end{tabular}\end{center}'
put('validation_results',text)

errs=np.array([r['energy_balance_rel_err'] for r in rows]);worst=max(rows,key=lambda r:r['energy_balance_rel_err']);regular=[r for r in rows if r['regime']=='regular' and r.get('poincare_period1_error',1)>-1]
bal=r'\C Across '+str(len(rows))+r' reported nonlinear power runs, the largest stored-energy-corrected relative balance error is '+fnum(max(errs))+r'; the median is '+fnum(np.median(errs))+r'. The worst case is \texttt{'+worst['name'].replace('_',r'\_')+r'}, whose harvested power is '+fnum(worst['mean_power_W'],'W')+'.\n\n'
periodic=[r for r in rows if r.get('poincare_period1_error',1)<1e-6]
if periodic:
    gap=max(abs(r['rotor_power_W']-r['mean_power_W'])/r['mean_power_W'] for r in periodic)
    bal+=r'\C Among period-one runs, the largest uncorrected mean-power mismatch is '+fnum(gap)+r'. Aperiodic runs retain their finite-window storage rate in the CSV. The latter is not a numerical defect.'
put('balance_results',bal)

rg=[r for r in best('ratios') if abs(r['R']-1.2)<1e-8 and abs(r['G']-.01)<1e-8];rmax=max(rg,key=lambda r:r['P_hat']);rmin=min(rg,key=lambda r:r['P_hat']);sing=lambda r:r['G']**2/(4*abs(r['R']-1))
t=r'\A The principal geometry grid uses $R=1.2$, $G=0.01$ ($\Gamma=120$), three logarithmically spaced mass ratios and three logarithmically spaced length ratios. A separate forcing sweep uses $R\in\{2.5,10\}$ and $G\in\{0.01,0.1,1,3\}$. Each geometry is evaluated at its analytic optimal damping, with the nonlinear power checked against the analytic prediction. The independently resolved damping curves test the shape of the optimum. The grid characterises this slice of the response surface; it is not a claim that these ratios are optimal at every $R,G$.'+'\n\n'
t+=r'\C The geometry-grid double/single power ratio ranges from '+fnum(min(r['P_hat']/sing(r) for r in rg))+r' to '+fnum(max(r['P_hat']/sing(r) for r in rg))+r'. The best sampled geometry has $\mu='+texnum(rmax['mu'])+r'$, $\lambda='+texnum(rmax['lambda_ratio'])+r'$, $\kappa='+texnum(rmax['kappa'])+r'$ and $\langle\widehat P\rangle='+texnum(rmax['P_hat'])+r'$. At the weakest geometry, the corresponding power is $'+texnum(rmin['P_hat'])+r'$.'+'\n\n'
for mode in ['both','pivot','middle','single']:
    dr=[r for r in best('damping') if (r['single'] if mode=='single' else (not r['single'] and r['generator_mode']==mode))]
    if dr:
        r=max(dr,key=lambda r:r['P_hat']);t+=r'\C '+mode.capitalize()+r' topology: $\kappa='+texnum(r['kappa'])+r'$, $\langle\widehat P\rangle/G^2='+texnum(r['P_hat']/r['G']**2)+r'$. '+'\n'
t+='\n'+r'\D In the strong centrifugal regime, both rods tend to follow the outward radial direction together. Relative motion at the middle joint is then small, so adding a middle generator does not automatically provide a second comparable source of power. The heavy-first-arm limit approaches a single heavy mass at the shorter first-arm reach, not a point mass at the full total length.'
similarity=json.loads((DATA/'similarity.json').read_text())
t+='\n\n'+r'\C A direct similarity test changes $M\to3M$, $L\to4L$, $\Omega\to\Omega/2$, $r_p\to4r_p$ and $c\to24c$. Predicted power scales by 6; the computed ratio is '+fnum(similarity['power_scale_ratio'],n=12)+r', with maximum dimensionless trajectory difference '+fnum(similarity['dimensionless_trajectory_max_difference'])+'.'
put('dimensionless_results',t)

c=r'\A The nonlinear search starts with 48 combinations: $\Omega\in\{2,4,6\}\ \mathrm{rad\,s^{-1}}$, $r_p\in\{0.05,0.20\}\ \mathrm m$ and eight logarithmically distributed damping values, expressed in the archive also as dimensionless $(R,G,\kappa)$. These physical values are merely coordinate mappings with $M=0.10\ \mathrm{kg}$ and $L=0.20\ \mathrm m$. They deliberately include centrifugal accelerations comparable with or smaller than gravity, outside the supplied turbine mounting-radius ranges. Six additional damping points resolve the strongest comparisons.'+'\n\n'
c+=r'\C The scan finds '+str(len(chaotic))+r' cases meeting the stated positive-exponent criterion. For the selected matched comparison, $R='+texnum(ch['R'])+r'$, $G='+texnum(ch['G'])+r'$ and $\mu=\lambda=1$. The best chaotic point in this group has $\kappa='+texnum(ch['kappa'])+r'$, $\langle\widehat P\rangle='+texnum(ch['P_hat'])+r'$ and $\widehat\Lambda='+texnum(ch['lyapunov_dimensionless'])+r'$. The best sampled regular point in the same group has $\kappa='+texnum(reg['kappa'])+r'$, $\langle\widehat P\rangle='+texnum(reg['P_hat'])+r'$ and $\widehat\Lambda='+texnum(reg['lyapunov_dimensionless'])+r'$. The chaotic/regular power ratio is '+fnum(ch['P_hat']/reg['P_hat'])+'.\n\n'
c+=r'\C On the illustrative SI mapping, these powers are '+fnum(ch['mean_power_W'],'W')+r' (chaotic) and '+fnum(reg['mean_power_W'],'W')+r' (regular), with exponents '+fnum(ch['lyapunov_1_per_s'],'s^{-1}')+r' and '+fnum(reg['lyapunov_1_per_s'],'s^{-1}')+r', respectively. Across the full nonlinear scan, the best sampled regular dimensionless power is '+fnum(regglobal['P_hat'])+r' at $(R,G)=('+texnum(regglobal['R'])+','+texnum(regglobal['G'])+r')$. Cross-group powers are not a controlled test of chaos because forcing changes.'+'\n\n'
c+=r'\D A chaotic orbit can have greater mean squared relative speed than a particular regular orbit, but damping simultaneously changes the motion and the energy supplied by the rotor. Neither a positive Lyapunov exponent nor a broad spectrum guarantees greater harvested power. The controlled comparison is the best regular and chaotic attractors at the same dimensionless forcing and geometry, with damping varied explicitly.'
rob=json.loads((DATA/'robustness.json').read_text())
long=by['robust_chaotic_long'];bb=np.array(long['block_power_W']);std=float(bb.std(ddof=1));sem=std/np.sqrt(len(bb))
c+='\n\n'+r'\C A separate long-run check at $(R,G)=('+texnum(long['R'])+','+texnum(long['G'])+r')$ and $\kappa='+texnum(long['kappa'])+r'$ discards 400 periods and averages 800. It gives '+fnum(long['mean_power_W'],'W')+r'; the standard deviation across sixteen 50-period blocks is '+fnum(std,'W')+r'. The naive block standard error is '+fnum(sem,'W')+r', which assumes independent blocks and is not a rigorous confidence interval. Two alternate initial conditions give '+fnum(by['robust_chaotic_basin0']['mean_power_W'],'W')+r' and '+fnum(by['robust_chaotic_basin1']['mean_power_W'],'W')+r' over 400-period averages.'
eps=rob['epsilon_checks']
c+='\n\n'+r'\C Benettin checks over 400 periods at perturbation sizes $10^{-6}$ and $10^{-7}$ give $\widehat\Lambda='+texnum(eps[0]['lambda_dimensionless'])+r'$ and $'+texnum(eps[1]['lambda_dimensionless'])+r'$; all corresponding blocks remain positive. This supports chaotic motion, while the exponent magnitude retains finite-time uncertainty.'
put('chaos_results',c)

tab=r'\C The following table reports the best computed powers for each supplied-range mapping. Damping is the equal active-joint coefficient in $\mathrm{N\,m\,s\,rad^{-1}}$. All powers and torque costs scale linearly with the illustrative mass when $\kappa$ is held fixed.'+'\n'+r'\begin{center}\small\begin{tabular}{rrrrrr}\toprule $\Omega$ (rad/s) & $r_p$ (m) & $\Gamma$ & $P_{\rm double}$ (W) & $P_{\rm single}$ (W) & $c_{\rm double}$\\\midrule'+'\n'
for d in sorted(doub,key=lambda r:r['Omega_rad_s']):
    ss=next(r for r in single if r['Omega_rad_s']==d['Omega_rad_s'] and r['r_p_m']==d['r_p_m'])
    tab+=' & '.join('$'+texnum(val)+'$' for val in [d['Omega_rad_s'],d['r_p_m'],d['R']/d['G'],d['mean_power_W'],ss['mean_power_W'],d['c_N_m_s_per_rad']])+r' \\'+'\n'
tab+=r'\bottomrule\end{tabular}\end{center}'+'\n\n'
Pt=.5*1.225*np.pi*(top['r_p_m']+top['l1_m']+top['l2_m'])**2*8**3*.45
rat=top['mean_power_W']/Pt
tab+=r'\C At the largest mapped harvest, the assumed turbine power is '+fnum(Pt,'W')+r', so harvest is '+fnum(rat)+r' of that output. The mean additional drive torque is '+fnum(top['mean_power_W']/top['Omega_rad_s'],'N\,m')+r'. That electricity is diverted from the rotor, not added to the turbine total.'
put('turbine_results',tab)

eta=.5;target=.001;minmass=.1*target/(eta*top['mean_power_W'])
sensor=r'\C The best mapped case provides '+fnum(eta*top['mean_power_W'],'W')+r' after the assumed conversion factor, or '+fnum(eta*top['mean_power_W']/target)+r' times the provisioned $1\ \mathrm{mW}$ budget. Ideal linear mass scaling would meet that budget at '+fnum(minmass,'kg')+r', if generator coefficient, friction, losses and all other assumptions scaled accordingly. This is not a practical minimum device mass: bearings, magnets, coils, rods and enclosure do not scale as point masses.'+'\n\n'
sensor+=r'\D In general the required idealised point mass is $M_{\rm req}=P_{\rm node}/[\eta L^2\Omega^3\langle\widehat P\rangle]$. This conversion is more informative than a single watt figure because $L$, $\Omega$, $R$ and the intended workload can be changed explicitly.'
put('sensor_results',sensor)

ver=r'\D \emph{As a way to increase total wind-turbine generation: no.} The exact balance is $\overline P_{\rm rotor}=\overline P_{\rm harvest}+\Delta E/\Delta t$. In bounded steady operation, usable electricity from the pendulum is paid for by extra rotor torque. With real conversion losses, the rotor pays more than the sensor receives. Chaos cannot alter this accounting.'+'\n\n'
ver+=r'\C \emph{As a source of local power: the ideal model can supply enough.} The illustrative best mapping produces '+fnum(top['mean_power_W'],'W')+r' from $0.10\ \mathrm{kg}$ of point mass and $0.20\ \mathrm m$ total reach. With the explicitly assumed $50\%$ usable-power factor, it exceeds a provisioned $1\ \mathrm{mW}$ sensor budget by a factor of '+fnum(eta*top['mean_power_W']/target)+r'. The underlying dimensionless result, rather than that arbitrary mass, is the transferable output.'+'\n\n'
ver+=r'\C \emph{A second pendulum and chaos have not earned their complexity here.} In the tested turbine mappings the double/single power ratio is '+fnum(min(ratios))+r'--'+fnum(max(ratios))+r'. In the matched nonlinear comparison, chaotic power is '+fnum(ch['P_hat']/reg['P_hat'])+r' times the best sampled regular power. These are finite-search results, not a theorem excluding every advantageous double-pendulum design.'+'\n\n'
ver+=r'\A \emph{Build only for a specific sensor-power problem.} A sensible next step is a guarded single-joint bench prototype, if a blade sensor otherwise needs difficult wiring or battery servicing. A double-joint chaotic prototype is not justified by these results alone. The decision would change only if a matched experiment demonstrated greater reliable net electrical power per installed mass, package volume, maintenance burden or cost.'+'\n\n'
ver+=r'\A \emph{What must be true before installation.} The real turbine operating distribution must spend enough time in the productive dimensionless region. The generator must realise the required damping without excessive friction, cogging or voltage loss. Rectification and storage must cover start-up, stopped wind and irregular output. The mechanism must tolerate centrifugal load, unrestricted rotation or engineered stops, blade vibration and fatigue without unacceptable aerodynamic or balance penalties. Its lifecycle benefit must exceed that of a simpler local supply. None of those hardware conditions is established by a point-mass simulation.'+'\n\n'
ver+=r'\D \emph{The design rule.} Select the workload first, then use $P=ML^2\Omega^3\langle\widehat P\rangle$, $c=ML^2\Omega\kappa$ and $\overline\tau_{\rm cost}=\overline P/\Omega$. \A Prefer the simplest regular mechanism meeting the measured duty cycle. Treat chaos as a behaviour to characterise, not a feature to pursue.'
put('verdict',ver)
(DATA/'headline_results.json').write_text(json.dumps(dict(best_mapping=top['name'],best_power_W=top['mean_power_W'],turbine_power_W=Pt,harvest_fraction=rat,double_single_ratio_min=min(ratios),double_single_ratio_max=max(ratios),chaotic_name=ch['name'],regular_matched_name=reg['name'],chaotic_regular_ratio=ch['P_hat']/reg['P_hat'],sensor_budget_W=target,assumed_efficiency=eta),indent=2))
print('Report fragments regenerated.')
