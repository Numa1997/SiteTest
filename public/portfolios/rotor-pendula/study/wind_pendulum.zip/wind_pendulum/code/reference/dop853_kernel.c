/* Optional acceleration of SciPy's DOP853 stage/error kernel.
 * Tableau, error coefficients and control parameters are supplied by SciPy.
 * No replacement equations, tolerances, interpolation or solver algorithm.
 */
#include <math.h>
#include <string.h>

static void rhs4(double s,const double*x,double*f,const double*p){
 double al=p[0],be=p[1],b=p[2],A=p[3],B=p[4],D=p[5],R=p[6],G=p[7],k0=p[8],k1=p[9];
 double q1=x[0],q2=x[1],u1=x[2],u2=x[3];
 f[0]=u1;f[1]=u2;
 if(p[11]>0.5){f[2]=-R*sin(q1)-G*cos(s+q1)-k0*u1;f[3]=f[2];return;}
 double si=sin(q1-q2),h=D*cos(q1-q2),det=A*B-h*h;
 double a=-D*si*(1+u2)*(1+u2)-al*(R*sin(q1)+G*cos(s+q1))-k0*u1+k1*(u2-u1);
 double z=D*si*(1+u1)*(1+u1)-be*b*(R*sin(q2)+G*cos(s+q2))-k1*(u2-u1);
 f[2]=(B*a-h*z)/det;f[3]=(A*z-h*a)/det;
}
static void rhs(double s,const double*x,double*f,const double*p,int n){
 rhs4(s,x,f,p);
 if(n==8){rhs4(s,x+4,f+4,p);return;}
 if(n==4)return;
 double al=p[0],be=p[1],b=p[2],R=p[6],G=p[7],k0=p[8],k1=p[9],scale=p[10];
 double q1=x[0],q2=x[1],u1=x[2],u2=x[3];
 double P=k0*u1*u1+k1*(u2-u1)*(u2-u1),tau;
 if(p[11]>0.5){
  P=k0*u1*u1;
  tau=-R*(f[2]*cos(q1)-(1+u1)*(1+u1)*sin(q1)+G*cos(s))+k0*u1;
 }else{
  tau=-R*(al*(f[2]*cos(q1)-(1+u1)*(1+u1)*sin(q1))+be*b*(f[3]*cos(q2)-(1+u2)*(1+u2)*sin(q2))+G*cos(s))+k0*u1;
 }
 f[4]=scale*P;f[5]=-scale*tau;
}
int dopstep(int n,const double*p,double t,const double*y,const double*f,double habs,double bound,double direction,double hmin,double maxstep,double rtol,const double*atol,const double*A,const double*B,const double*C,const double*E3,const double*E5,double*yn,double*fn,double*K,double*out){
 int rejected=0,attempts=0;
 habs=fmin(habs,maxstep);habs=fmax(habs,hmin);
 while(1){
  if(habs<hmin)return -1;
  if(++attempts>10000)return -2;
  double h=habs*direction,tn=t+h;
  if(direction*(tn-bound)>0)tn=bound;
  h=tn-t;habs=fabs(h);
  for(int j=0;j<n;j++)K[j]=f[j];
  for(int st=1;st<12;st++){
   double tmp[8];
   for(int j=0;j<n;j++){
    double sum=0;for(int k=0;k<st;k++)sum+=A[st*12+k]*K[k*n+j];
    tmp[j]=y[j]+h*sum;
   }
   rhs(t+C[st]*h,tmp,K+st*n,p,n);
  }
  for(int j=0;j<n;j++){
   double sum=0;for(int k=0;k<12;k++)sum+=B[k]*K[k*n+j];
   yn[j]=y[j]+h*sum;
  }
  rhs(tn,yn,fn,p,n);memcpy(K+12*n,fn,n*sizeof(double));
  double err5=0,err3=0;
  for(int j=0;j<n;j++){
   double z5=0,z3=0;
   for(int k=0;k<13;k++){z5+=E5[k]*K[k*n+j];z3+=E3[k]*K[k*n+j];}
   double sc=atol[j]+fmax(fabs(y[j]),fabs(yn[j]))*rtol;
   z5/=sc;z3/=sc;err5+=z5*z5;err3+=z3*z3;
  }
  double en=(err5==0&&err3==0)?0:habs*err5/sqrt((err5+.01*err3)*n);
  if(!isfinite(en))return -3;
  if(en<1){
   double factor=en==0?10:fmin(10,.9*pow(en,-.125));
   if(rejected)factor=fmin(1,factor);
   out[0]=tn;out[1]=habs*factor;out[2]=h;out[3]=attempts*12;
   return 0;
  }
  habs*=fmax(.2,.9*pow(en,-.125));rejected=1;
 }
}
