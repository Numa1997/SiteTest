"""Resolve damping between the strongest chaotic and regular coarse-grid points."""
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import json
from dataclasses import replace
import numpy as np
from model import Parameters
from study import worker,assemble
from lyapunov import task
ROOT=Path(__file__).resolve().parents[1]
def run(job):
    r=worker(job);return task(ROOT/'data/runs'/f'{r["name"]}.json')
if __name__=='__main__':
    base=json.loads((ROOT/'data/runs/chaos_o2_r1_c5.json').read_text());p=Parameters(**base['parameters'])
    jobs=[(f'chaos_refine_c{i}','chaos',replace(p,c=c),200,200,np.array([1.2,-.8,0.,0.])) for i,c in enumerate([.012,.018,.024])]
    p4=replace(p,Omega=4.)
    jobs += [(f'chaos_matched_refine_c{i}','chaos',replace(p4,c=c),200,200,np.array([1.2,-.8,0.,0.])) for i,c in enumerate([.015,.022,.045])]
    with ProcessPoolExecutor(max_workers=3) as pool:
        for f in as_completed([pool.submit(run,j) for j in jobs]):
            r=f.result();print(r['name'],r['mean_power_W'],r['lyapunov_dimensionless'],r['regime'],flush=True)
    assemble()
