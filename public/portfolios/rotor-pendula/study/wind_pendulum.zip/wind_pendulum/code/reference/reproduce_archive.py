"""Regenerate delivered trajectories at exactly the archived parameters.
The manifest also includes exploratory points beyond the primary finite grid.
Use --fresh to recompute; otherwise only missing runs are calculated.
"""
from pathlib import Path
import json,argparse
from concurrent.futures import ProcessPoolExecutor
from model import Parameters
from study import worker,assemble
ROOT=Path(__file__).resolve().parents[1]
if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--fresh',action='store_true');ap.add_argument('--workers',type=int,default=8);a=ap.parse_args()
    manifest=json.loads((ROOT/'data/run_manifest.json').read_text());jobs=[]
    for r in manifest:
        if a.fresh:
            for ext in ['json','npz']:(ROOT/'data/runs'/f'{r["name"]}.{ext}').unlink(missing_ok=True)
        jobs.append((r['name'],r['study'],Parameters(**r['parameters']),r['discard'],r['periods'],r['x0']))
    with ProcessPoolExecutor(max_workers=a.workers) as pool:
        for r in pool.map(worker,jobs):print(r['name'],r['mean_power_W'],flush=True)
    assemble()
