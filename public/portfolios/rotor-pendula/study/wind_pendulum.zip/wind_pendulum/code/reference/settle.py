"""Periodic-orbit initialization for extremely weakly damped middle-only modes.
A real 100+200-period DOP853 run follows the solved initial condition.
"""
from pathlib import Path
import json,argparse
from dataclasses import replace
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import root
from model import Parameters,System,RTOL,ATOL
from study import worker,assemble
ROOT=Path(__file__).resolve().parents[1]

def periodic_initial(p,x0):
    sys=System(p);x0=x0.copy();x0[:2]=(x0[:2]+np.pi)%(2*np.pi)-np.pi
    def fun(x):
        sol=solve_ivp(sys.rhs4,[0,2*np.pi],x,method='DOP853',rtol=RTOL,atol=ATOL,max_step=.1)
        return sol.y[:,-1]-x
    sol=root(fun,x0,tol=1e-10)
    err=float(np.max(abs(fun(sol.x))))
    if err>1e-8:raise RuntimeError(f'Periodic initialization failed: {err}')
    return sol.x,err

def settle(path):
    r=json.loads(path.read_text())
    if r.get('initialization')=='periodic shooting':return r
    z=np.load(ROOT/'data/runs'/f'{r["name"]}.npz');p=Parameters(**r['parameters'])
    x0=np.array([z[k][-1] for k in ['q1','q2','u1','u2']]);x0,err=periodic_initial(p,x0)
    path.unlink()
    new=worker((r['name'],r['study'],p,100,200,x0))
    new.update(initialization='periodic shooting',initial_periodic_residual=err,reason='Remove extremely slow free transients in weakly damped middle-only topology')
    path.write_text(json.dumps(new,indent=2));return new

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--workers',type=int,default=2);args=ap.parse_args()
    paths=[f for f in (ROOT/'data/runs').glob('*.json') if json.loads(f.read_text())['generator_mode']=='middle']
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for f in as_completed([pool.submit(settle,p) for p in paths]):
            r=f.result();print(r['name'],r['mean_power_W'],r['storage_rate_W']/r['mean_power_W'],flush=True)
    assemble()
