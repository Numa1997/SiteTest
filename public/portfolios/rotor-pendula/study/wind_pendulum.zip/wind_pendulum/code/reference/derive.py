"""Symbolically derive inertial Euler--Lagrange equations, verify printed form."""
from pathlib import Path
import sympy as S
OUT=Path(__file__).resolve().parents[1]/'data'
t=S.symbols('t',real=True)
m1,m2,l1,l2,rp,O,g,c0,c1=S.symbols('m_1 m_2 l_1 l_2 r_p Omega g c_0 c_1',positive=True)
a,b=S.Function('theta_1')(t),S.Function('theta_2')(t)
phi=O*t
p=S.Matrix([rp*S.cos(phi),rp*S.sin(phi)])
e=lambda q:S.Matrix([S.cos(q),S.sin(q)])
x1=p+l1*e(a); x2=x1+l2*e(b)
v1=x1.diff(t); v2=x2.diff(t)
T=S.trigsimp((m1*v1.dot(v1)+m2*v2.dot(v2))/2)
V=g*(m1*x1[1]+m2*x2[1]); L=T-V
F=(c0*(a.diff(t)-O)**2+c1*(b.diff(t)-a.diff(t))**2)/2
E=[S.trigsimp(S.diff(S.diff(L,q.diff(t)),t)-S.diff(L,q)+S.diff(F,q.diff(t))) for q in (a,b)]
A=(m1+m2)*l1**2; B=m2*l2**2; D=m2*l1*l2
wanted=[A*a.diff(t,2)+D*S.cos(a-b)*b.diff(t,2)+D*S.sin(a-b)*b.diff(t)**2+(m1+m2)*l1*(O**2*rp*S.sin(a-phi)+g*S.cos(a))+c0*(a.diff(t)-O)+c1*(a.diff(t)-b.diff(t)), B*b.diff(t,2)+D*S.cos(a-b)*a.diff(t,2)-D*S.sin(a-b)*a.diff(t)**2+m2*l2*(O**2*rp*S.sin(b-phi)+g*S.cos(b))+c1*(b.diff(t)-a.diff(t))]
assert all(S.trigsimp(x-y)==0 for x,y in zip(E,wanted))
OUT.mkdir(exist_ok=True)
(OUT/'sympy_derivation.txt').write_text('SymPy '+S.__version__+'\nT = '+str(T)+'\nV = '+str(V)+'\nF = '+str(F)+'\n\n'+'\n\n'.join('E'+str(i+1)+' = '+str(e)+' = 0' for i,e in enumerate(E))+'\n\nBoth equations agree symbolically with the numerical implementation.\n')
# Print compact algebraic form with stand-in symbols for time derivatives.
repl={a.diff(t,2):S.Symbol('alpha_1'),b.diff(t,2):S.Symbol('alpha_2'),a.diff(t):S.Symbol('omega_1'),b.diff(t):S.Symbol('omega_2'),a:S.Symbol('theta_1'),b:S.Symbol('theta_2')}
(OUT/'equations.tex').write_text('\n'.join('\\begin{multline}\n'+S.latex(z.xreplace(repl))+'=0.\n\\end{multline}' for z in wanted))
print('Symbolic Euler-Lagrange identities: PASS')
