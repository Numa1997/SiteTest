"""Long-run studies. All power points use DOP853, 100+200 rotor periods.
Damping: linear theory brackets a log search; nonlinear runs refine it.
"""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
from pathlib import Path
import json,csv,argparse,time
from dataclasses import asdict,replace
from concurrent.futures import ProcessPoolExecutor
import numpy as np
from scipy.optimize import minimize_scalar
from model import Parameters,integrate,linear_power,save_run
ROOT=Path(__file__).resolve().parents[1]

def optimal_linear(p):
    scale=p.M*p.L*p.Omega*max(p.rp,p.L)
    fun=lambda z:-linear_power(replace(p,c=scale*np.exp(z)))
    opt=minimize_scalar(fun,bounds=(-12,8),method='bounded',options={'xatol':1e-8})
    return scale*np.exp(opt.x)

def worker(job):
    name,study,p,discard,periods,x0=job
    dest=ROOT/'data/runs'/f'{name}.npz'; meta=ROOT/'data/runs'/f'{name}.json'
    if meta.exists(): return json.loads(meta.read_text())
    start=time.time(); r=integrate(p,discard=discard,periods=periods,x0=x0)
    save_run(dest,r)
    out=dict(name=name,study=study,solver_backend='SciPy DOP853 with compiled stage kernel' if os.environ.get('PENDULUM_NATIVE')=='1' else 'unmodified SciPy DOP853',R=p.rp/p.L,G=p.g/(p.Omega**2*p.L),mu=p.m2/p.m1,lambda_ratio=p.l2/p.l1,kappa=p.c/(p.M*p.L**2*p.Omega),P_hat=r['mean_power']/(p.M*p.L**2*p.Omega**3),Omega_rad_s=p.Omega,r_p_m=p.rp,m1_kg=p.m1,m2_kg=p.m2,l1_m=p.l1,l2_m=p.l2,c_N_m_s_per_rad=p.c,mean_power_W=r['mean_power'],rotor_power_W=r['rotor_power'],energy_balance_rel_err=r['balance'],lyapunov_1_per_s=float('nan'),regime='regular',generator_mode=p.mode,single=p.single,discard_periods=discard,average_periods=periods,storage_rate_W=r['storage_rate'],block_power_W=r['blocks'].tolist(),linear_power_W=linear_power(p),nfev=r['nfev'],elapsed_s=time.time()-start,parameters=asdict(p))
    meta.write_text(json.dumps(out,indent=2))
    return out

def jobs_main():
    jobs=[]
    # Dimensional mappings of the universal model, L=0.2 m, M=0.1 kg.
    for group,speeds,radii in [('small',[10.471975511965978,20.943951023931955,41.88790204786391],[.5,1.,1.5]),('large',[.8377580409572781,1.4660765716752369,2.0943951023931953],[20.,40.,60.])]:
        for i,(O,rp) in enumerate(zip(speeds,radii)):
            for mode in ('both','pivot','middle','single'):
                p=Parameters(Omega=O,rp=rp,mode='pivot' if mode=='single' else mode,single=mode=='single')
                co=optimal_linear(p)
                for k,f in enumerate([.7,1.,1.4] if mode=='both' else [1.]):
                    jobs.append((f'{group}_o{i}_r{i}_{mode}_c{k}',group,replace(p,c=co*f),100,200,None))
    # Primary dimensionless geometry study: R=1.2, G=0.01, 3x3 grid.
    O=np.sqrt(9.80665/(.2*.01))
    for mi,mu in enumerate([.01,.1,1.]):
        for li,lam in enumerate([.1,.316227766,1.]):
            p=Parameters(Omega=O,rp=.24,m1=.1/(1+mu),m2=.1*mu/(1+mu),l1=.2/(1+lam),l2=.2*lam/(1+lam))
            co=optimal_linear(p)
            for k,f in enumerate([1.]):
                jobs.append((f'ratios_m{mi}_l{li}_c{k}','ratios',replace(p,c=co*f),100,200,None))
    # Universal forcing/centrifugal sweep at two R, at linear-predicted c.
    for ri,R in enumerate([2.5,10.]):
        for gi,G in enumerate([.01,.1,1.,3.]):
            p=Parameters(Omega=np.sqrt(9.80665/(.2*G)),rp=R*.2)
            co=optimal_linear(p)
            for k,f in enumerate([1.]):
                jobs.append((f'universal_r{ri}_g{gi}_c{k}','universal',replace(p,c=co*f),100,200,None))
    # Resolved damping curves at R=5,G=0.1 for all generator placements.
    O=np.sqrt(9.80665/(.2*.1))
    for mode in ['both','pivot','middle','single']:
        p=Parameters(Omega=O,rp=1.,mode='pivot' if mode=='single' else mode,single=mode=='single')
        co=optimal_linear(p)
        for ci,f in enumerate([.1,.3,1.,3.]):
            jobs.append((f'damping_{mode}_c{ci}','damping',replace(p,c=co*f),100,200,None))
    return jobs

def jobs_chaos():
    jobs=[]
    # Deliberately outside supplied turbine mounting radii: forcing/resonance stress test.
    for oi,O in enumerate([2.,4.,6.]):
        for ri,rp in enumerate([.05,.2]):
            p=Parameters(Omega=O,rp=rp)
            for ci,c in enumerate([.00003,.0001,.0003,.001,.003,.01,.03,.1]):
                jobs.append((f'chaos_o{oi}_r{ri}_c{ci}','chaos',replace(p,c=c),200,200,np.array([1.2,-.8,0.,0.])))
    return jobs

def assemble():
    rows=[json.loads(f.read_text()) for f in sorted((ROOT/'data/runs').glob('*.json'))]
    fields=['study','Omega_rad_s','r_p_m','m1_kg','m2_kg','l1_m','l2_m','c_N_m_s_per_rad','mean_power_W','rotor_power_W','energy_balance_rel_err','lyapunov_1_per_s','regime','name','generator_mode','single','discard_periods','average_periods','storage_rate_W','linear_power_W','R','G','mu','lambda_ratio','kappa','P_hat']
    with (ROOT/'data/summary.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)
    return rows

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--suite',choices=['main','chaos','all'],default='all');ap.add_argument('--workers',type=int,default=8);args=ap.parse_args()
    jobs=(jobs_main() if args.suite in ('all','main') else [])+(jobs_chaos() if args.suite in ('all','chaos') else [])
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        for i,row in enumerate(pool.map(worker,jobs,chunksize=1)):
            print(f'{i+1}/{len(jobs)} {row["name"]} P={row["mean_power_W"]:.8g} W balance={row["energy_balance_rel_err"]:.2g}',flush=True)
    assemble()
