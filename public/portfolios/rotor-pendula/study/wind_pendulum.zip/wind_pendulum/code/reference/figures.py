"""Regenerate all final figures from saved long-run trajectories and metadata."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
from model import Parameters,System,linear_power
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'figures';OUT.mkdir(exist_ok=True)
for f in (ROOT/'fonts').glob('*.ttf'):fm.fontManager.addfont(str(f))
SANS=fm.FontProperties(fname=str(ROOT/'fonts/IBMPlexSans-Regular.ttf'))
MONO=fm.FontProperties(fname=str(ROOT/'fonts/IBMPlexMono-Regular.ttf'))
plt.rcParams.update({'font.family':SANS.get_name(),'font.size':10,'axes.labelsize':11,'axes.titlesize':12,'axes.spines.top':False,'axes.spines.right':False,'axes.edgecolor':'#8b8079','axes.labelcolor':'#1c1518','text.color':'#1c1518','xtick.color':'#4a413d','ytick.color':'#4a413d','figure.facecolor':'white','axes.facecolor':'white','savefig.facecolor':'white','pdf.fonttype':42,'svg.fonttype':'none','mathtext.fontset':'cm','legend.frameon':False})
MAIN='#7a1f2b';COMP='#4a413d';REF='#1c1518';FAINT='#8b8079'
rows=[json.loads(f.read_text()) for f in sorted((ROOT/'data/runs').glob('*.json'))]
byname={r['name']:r for r in rows}

def finish(fig,name):
    for ax in fig.axes:
        for label in ax.get_xticklabels()+ax.get_yticklabels():label.set_fontproperties(MONO);label.set_fontsize(8)
        ax.grid(alpha=.12,color=FAINT)
        ax.xaxis.get_offset_text().set_fontproperties(MONO)
        ax.yaxis.get_offset_text().set_fontproperties(MONO)
    fig.tight_layout(pad=1.5)
    for ext in ['svg','pdf']:fig.savefig(OUT/f'{name}.{ext}',bbox_inches='tight')
    plt.close(fig)

def bestgroups(study):
    base=[r for r in rows if r['study']==study or r['study']==study+'_opt'];groups={}
    for r in base:
        key=(r['R'],r['G'],r['mu'],r['lambda_ratio'],r['generator_mode'],r['single'])
        if key not in groups or r['mean_power_W']>groups[key]['mean_power_W']:groups[key]=r
    return list(groups.values())

def load(r):return np.load(ROOT/'data/runs'/f'{r["name"]}.npz')

def validation():
    e=np.load(ROOT/'data/runs/check_energy.npz');l=np.load(ROOT/'data/runs/check_linear.npz')
    fig,axs=plt.subplots(1,2,figsize=(9,3.2))
    axs[0].plot(e['gravitational_time']/e['slow_period'],e['energy_rel_error'],color=MAIN,lw=.8)
    axs[0].set(xlabel='Slow-mode periods',ylabel='Relative energy drift',title='Conservative dynamics')
    axs[1].plot(l['gravitational_time']/e['slow_period'],l['numerical'][0]/1e-5,color=MAIN,label='Nonlinear DOP853')
    axs[1].plot(l['gravitational_time'][::20]/e['slow_period'],l['analytic'][0,::20]/1e-5,'o',ms=3,mfc='none',mec=COMP,label='Analytic linear solution')
    axs[1].set(xlim=(0,5),xlabel='Slow-mode periods',ylabel=r'$\eta_1 / 10^{-5}$',title='Damped small angles');axs[1].legend(fontsize=8)
    finish(fig,'validation')

def damping():
    fig,ax=plt.subplots(figsize=(8.3,4.1))
    colors=[MAIN,COMP,FAINT,REF]
    for i,mode in enumerate(['both','pivot','middle','single']):
        rr=[r for r in rows if r['study']=='damping' and r['name'].startswith('damping_'+mode+'_')];rr=sorted(rr,key=lambda r:r['kappa'])
        p=Parameters(**rr[0]['parameters']);ks=np.geomspace(rr[0]['kappa'],rr[-1]['kappa'],180)
        from dataclasses import replace
        ys=[linear_power(replace(p,c=k*p.M*p.L*p.L*p.Omega))/(p.M*p.L*p.L*p.Omega**3*rr[0]['G']**2) for k in ks]
        ax.loglog(ks,ys,color=colors[i],ls='--' if mode=='single' else '-',lw=1,label={'both':'Double: both joints','pivot':'Double: pivot only','middle':'Double: middle only','single':'Single pendulum'}[mode])
        ax.loglog([r['kappa'] for r in rr],[r['P_hat']/r['G']**2 for r in rr],'o',color=colors[i],ms=4)
    ax.set(xlabel=r'Dimensionless damping $\kappa$',ylabel=r'$\langle\widehat P\rangle/G^2$');ax.legend(fontsize=9,ncol=2)
    finish(fig,'damping')

def geometry():
    rr=[r for r in bestgroups('ratios') if abs(r['R']-1.2)<1e-8 and abs(r['G']-.01)<1e-8];mus=sorted(set(r['mu'] for r in rr));ls=sorted(set(r['lambda_ratio'] for r in rr))
    Z=np.zeros((len(mus),len(ls)));K=Z.copy()
    for r in rr:
        i=np.argmin(abs(np.array(mus)-r['mu']));j=np.argmin(abs(np.array(ls)-r['lambda_ratio']));Z[i,j]=r['P_hat']/(r['G']**2/(4*abs(r['R']-1)));K[i,j]=r['kappa']
    from matplotlib.colors import LinearSegmentedColormap
    cmap=LinearSegmentedColormap.from_list('numa',['#ffffff','#c2a4a6',MAIN])
    fig,axs=plt.subplots(1,2,figsize=(9,4))
    for ax,V,title in zip(axs,[Z,K],['Double / single optimum power',r'Optimal $\kappa$']):
        im=ax.imshow(V,origin='lower',aspect='auto',cmap=cmap)
        ax.set_xticks(range(len(ls)),[f'{v:.2g}' for v in ls]);ax.set_yticks(range(len(mus)),[f'{v:.2g}' for v in mus]);ax.set(xlabel=r'Length ratio $\lambda$',ylabel=r'Mass ratio $\mu$',title=title)
        for i in range(len(mus)):
            for j in range(len(ls)):ax.text(j,i,f'{V[i,j]:.3g}',ha='center',va='center',fontsize=8,color='white' if V[i,j]>(V.min()+V.max())*.5 else REF,fontproperties=MONO)
        fig.colorbar(im,ax=ax,fraction=.045,pad=.03)
    finish(fig,'geometry')

def universal():
    rr=bestgroups('universal');fig,axs=plt.subplots(1,2,figsize=(9,3.6))
    for ax,R in zip(axs,[2.5,10.]):
        rs=sorted([r for r in rr if abs(r['R']-R)<1e-8],key=lambda r:r['R']/r['G']);x=[r['R']/r['G'] for r in rs]
        ax.semilogx(x,[r['P_hat']/r['G']**2 for r in rs],'o-',color=MAIN,label='Nonlinear optimum')
        ax.semilogx(x,[r['linear_power_W']/(r['parameters']['m1']+r['parameters']['m2'])/(r['parameters']['l1']+r['parameters']['l2'])**2/r['Omega_rad_s']**3/r['G']**2 for r in rs],'--',color=REF,label='Linear at same damping')
        ax.set(xlabel=r'$\Gamma=\Omega^2r_p/g$',ylabel=r'$\langle\widehat P\rangle/G^2$',title=f'R = {R:g}')
    axs[0].legend(fontsize=9);finish(fig,'universal')

def balance():
    r=next(r for r in rows if r['name']=='small_o0_r0_both_c1');z=load(r);p=Parameters(**r['parameters']);sys=System(p)
    s=z['t']*p.Omega;y=np.array([z[k] for k in ['q1','q2','u1','u2']]);E=sys.energy(s,y);dE=E-E[0];W=z['rotor_work_integral'];H=z['harvest_integral'];periods=(s-s[0])/(2*np.pi)
    fig,axs=plt.subplots(1,2,figsize=(9,3.5));mask=periods<3
    axs[0].plot(periods[mask],(W-H)[mask],color=MAIN,label='Rotor work − harvested energy')
    axs[0].plot(periods[mask],dE[mask],'--',color=REF,label='Stored-energy change');axs[0].set(xlabel='Rotor periods after transient',ylabel='Energy (J)');axs[0].legend(fontsize=8)
    axs[1].plot(periods,(W-H-dE)/H[-1],color=MAIN,lw=.8);axs[1].set(xlabel='Rotor periods after transient',ylabel='Balance residual / total harvest')
    finish(fig,'energy_balance')

def turbine():
    fig,axs=plt.subplots(2,2,figsize=(9,6.4))
    for j,group in enumerate(['small','large']):
        rr=bestgroups(group)
        for single,col,lab in [(False,MAIN,'Double: both'),(True,COMP,'Single')]:
            rs=sorted([r for r in rr if r['single']==single and (single or r['generator_mode']=='both')],key=lambda r:r['Omega_rad_s'])
            O=[r['Omega_rad_s'] for r in rs];P=[r['mean_power_W'] for r in rs]
            Pt=[.5*1.225*np.pi*(r['r_p_m']+r['l1_m']+r['l2_m'])**2*8**3*.45 for r in rs]
            axs[0,j].semilogy(O,P,'o-',color=col,label=lab)
            axs[1,j].semilogy(O,np.array(P)/Pt,'o-',color=col)
        axs[0,j].set(title=group.capitalize()+' rotor mapping',ylabel='Ideal harvested power (W)');axs[0,j].legend(fontsize=9)
        axs[1,j].set(xlabel=r'$\Omega$ (rad s$^{-1}$)',ylabel='Harvest / turbine output')
    finish(fig,'turbine_mapping')

def chaos():
    choice=json.loads((ROOT/'data/selection.json').read_text());c=byname[choice['chaotic']];reg=byname[choice['regular_matched']]
    rr=sorted([r for r in rows if r['study']=='chaos' and r['R']==c['R'] and r['G']==c['G']],key=lambda r:r['kappa'])
    fig,axs=plt.subplots(1,2,figsize=(9,3.6))
    axs[0].plot([r['kappa'] for r in rr],[r['P_hat'] for r in rr],color=FAINT,lw=1)
    axs[1].plot([r['kappa'] for r in rr],[r['lyapunov_dimensionless'] for r in rr],color=FAINT,lw=1)
    for regime,col,marker in [('chaotic',MAIN,'o'),('regular',COMP,'s')]:
        rs=[r for r in rr if r['regime']==regime]
        axs[0].scatter([r['kappa'] for r in rs],[r['P_hat'] for r in rs],color=col,marker=marker,label=regime)
        axs[1].scatter([r['kappa'] for r in rs],[r['lyapunov_dimensionless'] for r in rs],color=col,marker=marker)
    for ax in axs:ax.set_xscale('log');ax.set_xlabel(r'$\kappa$')
    axs[0].set(ylabel=r'$\langle\widehat P\rangle$');axs[0].legend(fontsize=9);axs[1].set(ylabel=r'$\Lambda/\Omega$');axs[1].axhline(0,ls='--',color=REF,lw=.8)
    finish(fig,'chaos_power')
    fig,axs=plt.subplots(1,2,figsize=(9,3.8))
    for ax,r,col in zip(axs,[c,reg],[MAIN,COMP]):
        z=load(r);stride=(len(z['t'])-1)//int(z['average_periods']);q=(z['q1'][::stride]+np.pi)%(2*np.pi)-np.pi;u=z['u1'][::stride]
        ax.scatter(q,u,s=10,alpha=.7,color=col);ax.set(xlabel=r'$q_1$ modulo $2\pi$ (rad)',ylabel=r"$q_1'$",title=f"{r['regime'].capitalize()}, κ = {r['kappa']:.3g}")
    finish(fig,'poincare')

if __name__=='__main__':
    validation();damping();geometry();universal();balance();turbine();chaos()
    print('All figures regenerated.')
