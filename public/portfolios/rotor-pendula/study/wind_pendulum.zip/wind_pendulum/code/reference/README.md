# Reproduce the pendulum-on-a-rotor study

All numbers in report tables and figures are generated from saved numerical runs.
The equations actually integrated are dimensionless. SI-valued parameter mappings
are recorded for convenience and the requested CSV/NPZ schema. No network access
is used by any simulation, plotting, or report-generation script.

## Environment

Python 3.11.17 was used. Create a Python 3.11 virtual environment and install the
versions in `requirements.txt` (package installation requires your permission):

```bash
cd wind_pendulum
python3.11 -m venv .venv
.venv/bin/python -m pip install -r code/requirements.txt
```

XeLaTeX, the Latin Modern fonts, and the LaTeX packages used in `report.tex` must
already be installed. Instrument Serif and IBM Plex font files and OFL licences
are included in `fonts/`; they need not be installed globally. The included
IBM Plex Sans Regular font was instantiated from the variable font at weight
400 and width 100 using fontTools. SVG text references these family names;
PDF figures embed the fonts.

## Exact regeneration commands

Execute from the `wind_pendulum` directory. Set thread counts to avoid nested
BLAS oversubscription. Eight worker processes were used for the main sweep;
worker count affects wall time, not the specified initial conditions.

```bash
export OPENBLAS_NUM_THREADS=1
export OMP_NUM_THREADS=1
.venv/bin/python code/derive.py
.venv/bin/python code/validate.py
.venv/bin/python code/study.py --suite all --workers 8
.venv/bin/python code/settle.py --workers 4
.venv/bin/python code/refine.py --workers 8
.venv/bin/python code/check_scaling.py
.venv/bin/python code/lyapunov.py --workers 8
.venv/bin/python code/validate.py --rk4 small_o0_r0_both_c1 small_o2_r2_single_c0
.venv/bin/python code/summarize.py
.venv/bin/python code/figures.py
xelatex -interaction=nonstopmode -halt-on-error report.tex
xelatex -interaction=nonstopmode -halt-on-error report.tex
```

Further verification commands, if required by the final manifest, are recorded
in `data/extra_commands.txt`. `summarize.py` must run after these checks and after
all Lyapunov classifications are available. `figures.py` reads the selection
written by `summarize.py`.

The study and refinement scripts cache completed runs by name, so the commands
can resume without repeating expensive integrations. To recompute every numerical
trajectory from scratch, move `data/runs` aside and create an empty `data/runs`
before running the commands. Do not mix cached results from edited equations or
changed tolerances with new results. Regenerating only report fragments and
figures does not rerun the integrations. This is the quickest way to inspect the
delivered results.

Full regeneration is computationally expensive. DOP853 is an explicit method;
large centrifugal ratios and a very light second mass with equal joint damping
introduce a much shorter relaxation time than the rotor period. No stiff solver,
quasi-static second-arm elimination, or repeated-cycle surrogate is substituted
for the required long runs. Periodic shooting is used only for initialization
and local damping optimisation; final reported powers are actual long-run
DOP853 integrations.

## Files and conventions

- `model.py`: dimensionless equations; independent reaction-force torque;
  inertial energy; analytic small-response power; trajectory serialization.
- `derive.py`: SymPy derivation from inertial Cartesian positions and Rayleigh
  dissipation; symbolic equality checks against the equations printed in the report.
- `study.py`: complete finite parameter grid and long-run means.
- `settle.py`: periodic initialization for slowly decaying middle-only modes.
- `refine.py`: local periodic-branch damping optimisation, followed by full long-run
  verification. Its one-period trial integrals are optimisation diagnostics.
- `lyapunov.py`: Benettin nearby-trajectory renormalisation at fixed forcing phase.
- `validate.py`: conservative energy, analytic damped linear response, fixed-step RK4.
- `check_scaling.py`: numerical similarity check under mass and length rescaling.
- `summarize.py`, `figures.py`: report fragments and all final figures.

`Omega > 0`: `s = Omega*t`; `q_i = theta_i - s`; `u_i = q_i'`.
Absolute angles are unwrapped and measured anticlockwise from inertial +x.
`tau_on_rotor` is positive in the rotor's direction of rotation. Positive rotor
power supplied to the pendulum is `-Omega*tau_on_rotor`. `P_harvest` is nonnegative.
Joint modes are `both`, `pivot`, `middle`; the single pendulum has only the pivot
generator and duplicates its sole angle/velocity in the second output column.

`Omega = 0` validation uses gravitational time `tau=t*sqrt(g/L)` internally;
NPZ arrays still contain SI time and absolute inertial angles/velocities.

`data/summary.csv` includes the twelve requested columns, followed by run identity,
topology, window lengths, storage rate, linear prediction, and dimensionless
coordinates. `energy_balance_rel_err` means

```
abs(W_rotor - H - (E_end-E_start)) / abs(H)
```

It is not the uncorrected difference between two finite-window powers. For a
chaotic window, that difference can be physical energy storage. The JSON sidecar
for each run records four 50-period power blocks, the initial condition protocol,
solver evaluation counts, and Lyapunov diagnostics. The `.npz` file contains the
required time, angle, angular velocity, electrical power, and reaction torque
arrays, along with scalar parameters and integrated work/energy. `_lyapunov.npz`
files are auxiliary sections from the tangent calculation, not separate power
runs. Validation files are labelled `check_energy` and `check_linear`.

Each row is a specified orbit and averaging window, not an ensemble average over
initial conditions. `regular` means the finite-time chaos criterion was not met;
see the exponent blocks and Poincare diagnostics for the actual evidence.
The summary must not be interpreted as a certified global optimum over basins.

No simulation requires downloading the cited source datasheets. Source URLs,
versions, relevant specifications and access dates are in the report and in
`sources/README.md`. These specifications are inputs, not measurements by us.

## Optional stage-kernel acceleration

The largest equal-damping/light-mass cases are stiff for explicit DOP853. The
completed study uses an optional local C stage kernel for some runs, while the
initial turbine cases and independent RK4 checks use the reference Python path.
The kernel is optional: all commands above work with unmodified SciPy when
`PENDULUM_NATIVE` is unset or zero. To use the acceleration with an existing GCC:

```bash
export PENDULUM_NATIVE=1
```

`accelerator.py` compiles `dop853_kernel.c` locally and registers a process-local
DOP853 subclass with `solve_ivp`. It uses SciPy's actual tableau, embedded error
coefficients, step-size factors, and dense interpolation; only arithmetic for a
trial step is moved into C. No SciPy installation files are modified. No other
packages are needed or installed. Set `PENDULUM_NATIVE=0` to use the original
implementation. The complete 200-period cross-check against unmodified SciPy is
in `data/native_validation.json`. The C code and compiler flag disabling fused
multiply-add contraction are included. Floating-point trajectories need not be
bit-identical across implementations, especially in a chaotic regime.

## Reproduce the delivered archive, including exploratory runs

The delivered finite grid and supplementary exploratory runs are specified exactly
in `data/run_manifest.json`, including every dimensional mapping, initial state,
and transient/averaging interval. To regenerate every delivered power trajectory,
use this command in place of the study and refinement commands above:

```bash
PENDULUM_NATIVE=1 .venv/bin/python code/reproduce_archive.py --fresh --workers 8
.venv/bin/python code/validate.py
.venv/bin/python code/lyapunov.py --workers 8
.venv/bin/python code/check_scaling.py
.venv/bin/python code/validate.py --rk4 small_o0_r0_both_c1 small_o2_r2_single_c0
.venv/bin/python code/summarize.py
.venv/bin/python code/figures.py
xelatex -interaction=nonstopmode -halt-on-error report.tex
xelatex -interaction=nonstopmode -halt-on-error report.tex
```

`robustness.py` regenerates the longer chaos-window and perturbation-size checks;
its chosen original matched pair is recorded in `data/robustness.json`.
`chaos_refine.py` regenerates the six supplementary damping points. Read `STATUS.md`
for the five unfinished Lyapunov entries at the requested stop. Regenerating these
will fill their NaN values; the delivered report does not claim they were measured.
