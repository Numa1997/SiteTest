"""Benettin largest conditional exponent, fixed forcing phase.
Velocity norm uses q'= (omega-Omega)/Omega; phase is not perturbed.
Regular rows: 24 periods after tangent alignment; chaotic candidates: 200.
"""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
from pathlib import Path
import json,argparse
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
from scipy.integrate import solve_ivp
from model import Parameters,System,RTOL,ATOL
from study import assemble
ROOT=Path(__file__).resolve().parents[1]

def benettin(p,x0,s0,periods=200,eps=1e-6,align=8):
    sys=System(p);v=np.array([1.,.3,-.2,.4]);
    if p.single:v=np.array([1.,1.,.3,.3])
    v/=np.linalg.norm(v);x=np.asarray(x0).copy();step=np.pi/2;logs=[];samples=[]
    fun=sys.rhs8
    for i in range(4*(periods+align)):
        s=s0+i*step
        y0=np.r_[x,x+eps*v]
        sol=solve_ivp(fun,[s,s+step],y0,method='DOP853',rtol=RTOL,atol=ATOL,max_step=.15)
        if not sol.success:raise RuntimeError(sol.message)
        x=sol.y[:4,-1];dv=sol.y[4:,-1]-x;norm=np.linalg.norm(dv)
        if norm==0:raise RuntimeError('Tangent collapsed: shorten renormalization interval')
        v=dv/norm
        if i>=4*align:
            logs.append(np.log(norm/eps))
            if (i+1)%4==0:samples.append(x.copy())
    logs=np.array(logs);lam=float(logs.sum()/(periods*2*np.pi))
    blocks=np.array([v.sum()/(len(v)*step) for v in np.array_split(logs,4)])
    return dict(lambda_dimensionless=lam,lambda_per_s=lam*p.Omega,blocks=blocks.tolist(),poincare=np.array(samples),epsilon=eps,periods=periods)

def task(path,force=False):
    meta=json.loads(path.read_text());name=meta['name']
    if np.isfinite(meta.get('lyapunov_1_per_s',float('nan'))) and not force:return meta
    z=np.load(ROOT/'data/runs'/f'{name}.npz');p=Parameters(**meta['parameters']);n=int(z['average_periods']);stride=(len(z['t'])-1)//n
    points=np.array([z[k][::stride] for k in ['q1','q2','u1','u2']]).T
    # Periodicity is checked after wrapping angles, allowing synchronous rotations.
    dif=np.diff(points[-51:],axis=0);dif[:,:2]=(dif[:,:2]+np.pi)%(2*np.pi)-np.pi
    period_error=float(np.max(abs(dif)))
    isperiodic=period_error<1e-6
    # Integrate Benettin from a settled state; finite-time error assessed in blocks.
    periods=24 if isperiodic else 200
    result=benettin(p,points[-1],float(z['t'][-1]*p.Omega),periods=periods)
    lam=result['lambda_dimensionless'];blocks=np.array(result['blocks'])
    regime='chaotic' if lam>0.002 and np.min(blocks)>0 else 'regular'
    meta.update(lyapunov_1_per_s=result['lambda_per_s'],lyapunov_dimensionless=lam,lyapunov_blocks=blocks.tolist(),lyapunov_periods=periods,lyapunov_epsilon=result['epsilon'],poincare_period1_error=period_error,regime=regime)
    # Keep section after full tangent calculation for an independently extended orbit.
    np.savez_compressed(ROOT/'data/runs'/f'{name}_lyapunov.npz',poincare=result['poincare'],blocks=blocks,lambda_dimensionless=lam,Omega=p.Omega)
    path.write_text(json.dumps(meta,indent=2));return meta

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--workers',type=int,default=8);ap.add_argument('--study');ap.add_argument('--names',nargs='*');args=ap.parse_args()
    paths=sorted((ROOT/'data/runs').glob('*.json'))
    if args.study:paths=[p for p in paths if json.loads(p.read_text())['study']==args.study]
    if args.names:paths=[p for p in paths if p.stem in args.names]
    with ProcessPoolExecutor(max_workers=args.workers) as pool:
        fs={pool.submit(task,p):p for p in paths}
        for i,f in enumerate(as_completed(fs)):
            r=f.result();print(f'{i+1}/{len(paths)} {r["name"]} lambda/Omega={r["lyapunov_dimensionless"]:.7g} {r["regime"]}',flush=True)
    assemble()
