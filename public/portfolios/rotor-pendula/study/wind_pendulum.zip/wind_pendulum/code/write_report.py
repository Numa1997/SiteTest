"""Assemble the report and human-readable audit from computed results."""
from pathlib import Path
import json,sys,platform
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
rows=json.loads((ROOT/'data/all_results.json').read_text());nl=[r for r in rows if r['source']=='nonlinear'];by={r['name']:r for r in nl}
audit=json.loads((ROOT/'data/audit.json').read_text());eps=json.loads((ROOT/'data/epsilon_sensitivity.json').read_text())
M=[r for r in nl if r['study']=='corrected_mapping'];ch=[r for r in nl if r['study']=='chaos_scan']
S=[r for r in M if r['single']];rat=[by[r['name'].replace('_single','_both')]['mean_power_W']/r['mean_power_W'] for r in S]
best=max(S,key=lambda r:r['mean_power_W']);reg=by['chaos_matched_refine_c1'];cha=by['chaos_o1_r1_c6'];long=by['robust_chaotic_long']
def n(x,d=3):return f'{x:.{d}g}'
def table_map(group):
 out=[]
 for r in sorted([r for r in S if r['name'].startswith('map_'+group)],key=lambda r:(r['Omega_rad_s'],r['r_p_m'])):
  d=by[r['name'].replace('_single','_both')];mark=r'$^{\dagger}$' if not r['linear_valid'] or not d['linear_valid'] else ''
  out.append(' & '.join([n(r['Omega_rad_s'],5),n(r['r_p_m'],4),n(r['R_rotor_m'],4),n(r['R_nd'],4),n(r['G_nd'],4),n(1000*r['mean_power_W'],4)+mark,n(1000*d['mean_power_W'],4)+mark,n(d['mean_power_W']/r['mean_power_W'],4)])+r' \\')
 return '\n'.join(out)
def fig(file,caption,height='57mm'):
 return '\\begin{figure}[H]\\centering\\includegraphics[height='+height+']{figures/'+file+'.pdf}\\caption{'+caption+'}\\end{figure}'
parts=[]
parts.append(r'''\documentclass[10pt,a4paper]{article}
\usepackage[margin=18mm]{geometry}
\usepackage{fontspec,unicode-math,amsmath,graphicx,booktabs,array,tabularx,float,xcolor,titlesec,fancyhdr,hyperref,tcolorbox}
\tcbuselibrary{skins}
\setmainfont{Latin Modern Roman}\setmathfont{Latin Modern Math}
\newfontfamily\sectionface[Path=fonts/]{InstrumentSerif-Regular.otf}
\definecolor{accent}{HTML}{7a1f2b}
\titleformat{\section}{\sectionface\color{accent}\LARGE}{\thesection}{.6em}{}
\titleformat{\subsection}{\sectionface\color{accent}\large}{}{0pt}{}
\titlespacing*{\section}{0pt}{0pt}{9pt}
\hypersetup{colorlinks=true,linkcolor=accent,urlcolor=accent}
\pagestyle{fancy}\fancyhf{}\fancyhead[L]{\small Wind-driven rotor pendula}\fancyhead[R]{\small 14 October 2026}\fancyfoot[C]{\thepage}
\setlength{\headheight}{14pt}\setlength{\parindent}{0pt}\setlength{\parskip}{6pt}
\setlength{\abovedisplayskip}{6pt}\setlength{\belowdisplayskip}{6pt}
\newcommand{\D}{\textcolor{accent}{\textsc{Derived.}}\enspace}
\newcommand{\C}{\textcolor{accent}{\textsc{Computed.}}\enspace}
\newcommand{\A}{\textcolor{accent}{\textsc{Assumed.}}\enspace}
\newcommand{\page}[1]{\clearpage\section{#1}}
\begin{document}
{\sectionface\color{accent}\fontsize{33}{35}\selectfont Wind-driven rotor pendula}\par
{\large A corrected, reproducible study of harvesting rotor energy}\par
Prepared for Numa Koudsie\hfill 14 October 2026
\begin{tcolorbox}[enhanced,frame hidden,colback=white,boxrule=0pt,borderline west={4pt}{0pt}{accent},left=10pt,right=5pt,top=5pt,bottom=5pt]
\sectionface\large Abstract\par\normalfont
\C On 18 physically admissible mountings, a single pendulum supplies @SMIN@--@SMAX@ mW and exceeds the equal-mass, equal-reach double pendulum at every point. Double/single ratios are @RMIN@--@RMAX@. A matched nonlinear example gives 0.379 W on a regular orbit and approximately 0.244 W on a longer chaotic window. Chaos confers no advantage in this comparison.

\D The generator removes energy from the rotor. At fixed angular speed, the rotor must replace the harvested energy plus any change in stored mechanical energy. This mechanism cannot increase net turbine output.

\A A 50\% electrical conversion efficiency and a specified low-duty-cycle sensor schedule are reference design assumptions. \D Datasheet typical currents give a @BUDGET@ $\mu$W reference load. \C Ideal power is sufficient, but centrifugal acceleration excludes many mountings for the specified accelerometer.
\end{tcolorbox}
\section*{Question and scope}
\A Consider a sensor node on a blade whose hub turns at prescribed constant angular speed. A pendulum attached to the blade responds to gravity and the acceleration of its moving pivot. Generators brake joint motion. The useful question is whether this small, local power supply is worth its mechanical complexity, rather than whether it creates additional turbine energy.

\A The ideal model uses point masses, rigid massless rods, a planar rotor, viscous generator torques and no aerodynamic forces, bearing friction, electrical thresholds or structural flexibility. The single comparator places the same total mass at the same total reach. These assumptions make the mechanical comparison controlled; they do not describe a qualified blade installation.

\C The supplied three numerical anchors were reproduced before modifying the study. Corrected results come from 111 nonlinear runs and 49 linear evaluations. All 54 original chaos-scan parameter sets were rerun. The five unfinished legacy middle-joint exponents remain explicitly ``not measured''.

\D Every substantive statement is marked Derived (algebra or source-based calculation), Computed (numerical result), or Assumed (scenario or design choice). Source specifications are used as stated typical values, not measurements of a prototype.
''')
parts.append(r'''\page{Geometry and the Lagrangian}
\A Let $s=\Omega t$, $\mathbf e(a)=(\cos a,\sin a)$, and take inertial $+y$ upwards. Both absolute rod angles $\theta_i$ increase anticlockwise from $+x$. The pivot, first mass and second mass have positions
\begin{align}
\mathbf x_p&=r_p\mathbf e(s),&
\mathbf x_1&=\mathbf x_p+l_1\mathbf e(\theta_1),&
\mathbf x_2&=\mathbf x_1+l_2\mathbf e(\theta_2).
\end{align}
'''+fig('01_geometry',r'\D Exact geometry of the planar model, drawn schematically. The pivot follows a circle; the two generator speeds are relative joint speeds, not absolute rod speeds.','52mm')+r'''
\D Write $M=m_1+m_2$, $L=l_1+l_2$, $A_d=Ml_1^2$, $B_d=m_2l_2^2$, $D_d=m_2l_1l_2$ and $\delta=\theta_1-\theta_2$. Differentiating the positions and using $\mathbf e'(a)\cdot\mathbf e'(b)=\cos(a-b)$ gives
\begin{align}
T={}&\tfrac12M\Omega^2r_p^2+\tfrac12 A_d\dot\theta_1^2+\tfrac12B_d\dot\theta_2^2+D_d\cos\delta\,\dot\theta_1\dot\theta_2\notag\\
&+\Omega r_p\big[Ml_1\dot\theta_1\cos(\theta_1-s)+m_2l_2\dot\theta_2\cos(\theta_2-s)\big],\\
V={}&g\big[Mr_p\sin s+Ml_1\sin\theta_1+m_2l_2\sin\theta_2\big].
\end{align}
\D The cross terms in $T$ are essential: each mass moves both with the pivot and relative to it. Dropping those terms would lose the forcing caused by the rotor. The gravity potential is the sum of each mass times its inertial height.

\A With damping coefficients $c_0,c_1\ge0$, Rayleigh's dissipation function is
\begin{equation}
\mathcal R=\tfrac12c_0(\dot\theta_1-\Omega)^2+\tfrac12c_1(\dot\theta_2-\dot\theta_1)^2.
\end{equation}
\D The dissipative generalized torque is $-\partial\mathcal R/\partial\dot\theta_i$. An ideal generator converts precisely this dissipated mechanical power into harvest. A real generator has additional losses, accounted for later through an assumed efficiency.
''')
parts.append(r'''\page{Equations and dimensionless coordinates}
\D Apply $\frac{d}{dt}\partial T/\partial\dot\theta_i-\partial T/\partial\theta_i+\partial V/\partial\theta_i+\partial\mathcal R/\partial\dot\theta_i=0$. The two inertial equations are
\begin{align}
0={}&A_d\ddot\theta_1+D_d\cos\delta\,\ddot\theta_2+D_d\sin\delta\,\dot\theta_2^2\notag\\
&+Ml_1[\Omega^2r_p\sin(\theta_1-s)+g\cos\theta_1]\notag\\
&+c_0(\dot\theta_1-\Omega)+c_1(\dot\theta_1-\dot\theta_2),\\
0={}&B_d\ddot\theta_2+D_d\cos\delta\,\ddot\theta_1-D_d\sin\delta\,\dot\theta_1^2\notag\\
&+m_2l_2[\Omega^2r_p\sin(\theta_2-s)+g\cos\theta_2]+c_1(\dot\theta_2-\dot\theta_1).
\end{align}
\D For example, the $D_d\sin\delta\,\dot\theta_2^2$ term combines derivatives of the cross kinetic energy. The $\Omega^2r_p$ terms result from pivot acceleration and pull the arms towards the outward blade direction. Gravity supplies time-periodic forcing in blade coordinates.

\D Define $q_i=\theta_i-s$, $u_i=dq_i/ds$, $a=l_1/L$, $b=l_2/L$, $\beta=m_2/M$, and
\begin{equation}
R=\frac{r_p}{L},\quad G=\frac{g}{\Omega^2L},\quad\Gamma=\frac{\Omega^2r_p}{g}=\frac RG,\quad
\mu=\frac{m_2}{m_1},\quad\lambda_\ell=\frac{l_2}{l_1},\quad\kappa_i=\frac{c_i}{ML^2\Omega}.
\end{equation}
\D $R$ measures pivot radius relative to pendulum reach; $G$ measures gravity relative to rotor acceleration at that reach; $\Gamma$ is the centrifugal/gravitational acceleration ratio. The rotor radius is denoted $R_{\rm rot}$, and the turbine tip-speed ratio $\lambda_T$, avoiding two different uses of $R$ and $\lambda$.

\D Divide the equations by $ML^2\Omega^2$, set $A=a^2$, $B=\beta b^2$, $D=\beta ab$, and $d=q_1-q_2$. Then
\begin{align}
Aq_1''+D\cos d\,q_2''={}&-D\sin d(1+u_2)^2-a[R\sin q_1+G\cos(s+q_1)]\notag\\
&-\kappa_0u_1+\kappa_1(u_2-u_1),\\
Bq_2''+D\cos d\,q_1''={}&D\sin d(1+u_1)^2-\beta b[R\sin q_2+G\cos(s+q_2)]\notag\\
&-\kappa_1(u_2-u_1).
\end{align}
\D This is the unchanged supplied model. The determinant $AB-D^2\cos^2d$ is positive for positive masses and rods. Both generators use $c_0=c_1=c$; pivot-only uses $c_1=0$; middle-only uses $c_0=0$.
''')
parts.append(r'''\page{Energy cost and linear response}
\D The ideal mechanical harvest and dimensionless power are
\begin{equation}
P_h=c_0\Omega^2u_1^2+c_1\Omega^2(u_2-u_1)^2,\qquad \widehat P=\frac{P_h}{ML^2\Omega^3}.
\end{equation}
\D Reconstruct the pivot reaction from Newton's law. Its transverse force combination and the torque on the rotor are
\begin{align}
F_\perp={}&Ml_1(\ddot\theta_1\cos q_1-\dot\theta_1^2\sin q_1)
+m_2l_2(\ddot\theta_2\cos q_2-\dot\theta_2^2\sin q_2)+Mg\cos s,\\
\tau_{\rm rotor}={}&-r_pF_\perp+c_0\Omega u_1,\qquad P_{\rm rotor}=-\Omega\tau_{\rm rotor}.
\end{align}
\D Substitution into $d(T+V)/dt$ gives
\begin{equation}
\frac{dE}{dt}=P_{\rm rotor}-P_h,\qquad
\overline P_{\rm rotor}=\overline P_h+\frac{E(t_b)-E(t_a)}{t_b-t_a}.
\end{equation}
\D A chaotic finite window can store energy; its mean rotor input need not equal its mean harvest exactly. For a period-one steady orbit, the storage term vanishes. Gravity is conservative and returns to the same rotor phase each period: it does not supply a net free energy source.

\D Linearize about $q_i=0$ and retain first order in gravity forcing. With $\mathbf q=\Re(\mathbf z e^{i\Omega t})$,
\begin{equation}
(\mathbf K-\Omega^2\mathbf M+i\Omega\mathbf C)\mathbf z=\mathbf f,
\qquad \overline P_{h,\rm lin}=\tfrac12\Omega^2\mathbf z^*\mathbf C\mathbf z,
\end{equation}
\begin{equation}
\mathbf M=\begin{pmatrix}A_d&D_d\\D_d&B_d\end{pmatrix},\quad
\mathbf K=\Omega^2\begin{pmatrix}Ml_1r_p+D_d&-D_d\\-D_d&m_2l_2r_p+D_d\end{pmatrix},\quad
\mathbf C=\begin{pmatrix}c_0+c_1&-c_1\\-c_1&c_1\end{pmatrix},\quad
\mathbf f=-g\binom{Ml_1}{m_2l_2}.
\end{equation}
\D For the equal-mass, equal-reach single comparator, $q''+\kappa q'+Rq=-G\cos s$. Therefore
\begin{equation}
\frac{\overline{\widehat P}_{\rm lin}}{G^2}=\frac{\kappa}{2[(R-1)^2+\kappa^2]},\quad
\kappa_* = |R-1|,\quad
\overline P_{*,\rm lin}=\frac{MLg^2}{4\Omega|r_p-L|}.
\end{equation}
\D The apparent singularity at $R=1$, $c\to0$ signals breakdown of the small-response model. It is not unlimited extractable power.

\A Linear theory is accepted here only when a nonlinear confirmation has peak $|q_i|<0.3$ rad and power disagreement below 2\%. Otherwise a local nonlinear periodic-branch damping search is used, bounded between half and twice the linear-optimal damping. No result is claimed to be a global optimum over attractors.
''')
parts.append(r'''\page{Corrected fast-rotor mappings}
\A Use $v=8$ m/s, $\lambda_T=7$, $\rho=1.225$ kg/m$^3$, and $C_p=0.45$. The scenario sets
\begin{equation}
R_{\rm rot}=\frac{\lambda_Tv}{\Omega}=\frac{56\ {
m m/s}}{\Omega},\qquad
P_T=\tfrac12\rho\pi R_{\rm rot}^2v^3C_p.
\end{equation}
\A The three pivot fractions are $r_p/R_{\rm rot}=0.3,0.6,0.9$ at each of the three angular speeds. Every pivot lies inside its rotor. Equal masses $m_1=m_2=0.05$ kg and rods $l_1=l_2=0.10$ m give $M=0.10$ kg, $L=0.20$ m. The single comparator uses $M$ at reach $L$.

\C Table 1 reports nonlinear confirmations; S denotes the single pendulum and D the double with both generators. Powers are mechanical harvest, before conversion. All fast-rotor rows meet the linear validity rule. Damping and all rotor-work values are in \texttt{data/summary.csv}.
\begin{table}[H]\centering\small
\caption{\C Fast-rotor cases. $\Omega$ in rad/s; radii in m; powers in mW. Every row specifies $R,G$.}
\begin{tabular*}{\textwidth}{@{\extracolsep{\fill}}rrrrrrrr@{}}\toprule
$\Omega$&$r_p$&$R_{\rm rot}$&$R$&$G$&$P_S$&$P_D$&D/S\\\midrule
@SMALLTABLE@
\bottomrule\end{tabular*}\end{table}
'''+fig('02_mapping_power',r'\C Corrected nonlinear powers at the 18 sampled mountings, each with $M=0.10$ kg and $L=0.20$ m. Single and double curves share forcing and rotor radius. Connecting lines guide the eye; they are not an interpolated optimization over the entire ranges.','62mm')+r'''
\C The largest corrected harvest is @BEST@ mW at $\Omega=@BESTO@$ rad/s, $r_p=@BESTRP@$ m, $R=@BESTR@$ and $G=@BESTG@$. Its assumed baseline turbine output is @BESTT@ W, so harvest is @BESTF@ of baseline output. This fraction is a cost to the rotor, not an increase in turbine electricity.
''')
parts.append(r'''\page{Corrected slow-rotor mappings}
\C The same pivot fractions cover the slow angular-speed interval. The rotor radii are larger because tip speed is held fixed. The studied envelope is a 3-by-3 sampling for each turbine class, not a continuous search over speeds and radii.
\begin{table}[H]\centering\small
\caption{\C Slow-rotor cases, with the same units and comparator as Table 1. A dagger marks a mounting where at least one topology requires nonlinear optimization.}
\begin{tabular*}{\textwidth}{@{\extracolsep{\fill}}rrrrrrrr@{}}\toprule
$\Omega$&$r_p$&$R_{\rm rot}$&$R$&$G$&$P_S$&$P_D$&D/S\\\midrule
@LARGETABLE@
\bottomrule\end{tabular*}\end{table}
\C Five confirmations fail the peak-deflection rule and therefore use local nonlinear damping maxima, followed by 100 discarded and 200 averaged periods:
\begin{table}[H]\centering\small
\caption{\C Nonlinear cases; $R,G$ and peak angular deflection are explicit. Powers in the preceding tables use these refined dampings.}
\begin{tabular}{lrrrr}\toprule
Case&$R$&$G$&$c$ (N m s/rad)&peak $|q|$ (rad)\\\midrule
@INVALIDTABLE@
\bottomrule\end{tabular}\end{table}
\D A pendulum on a slow, large rotor is strongly biased outwards only if $\Gamma=\Omega^2r_p/g$ is large. Rotor size alone does not guarantee a small oscillation: at fixed pivot fraction, $\Gamma=(r_p/R_{\rm rot})\lambda_Tv\Omega/g$ decreases with angular speed.

\D In the strong centrifugal limit, $r_p\gg L$, the single optimum becomes $\overline P_*\approx MLg^2/(4\Omega r_p)$. Since $\Omega r_p=f\lambda_Tv$ at a fixed blade fraction $f$, its leading power is nearly independent of rotor angular speed. This explains the almost flat slow-rotor curves; the fast, inner mapping has a finite-$L/r_p$ correction.

\C Across all 18 matched mountings, D/S ranges from @RMIN@ to @RMAX@. The additional joint does not overcome the less favourable distribution of mass and reach. This result applies to the stated comparator, damping law, geometries and sampled branches. It does not rule out every possible double-pendulum design.
''')
parts.append(r'''\page{Generator placement and relative motion}
\A Hold $R=5$, $G=0.1$, $\mu=\lambda_\ell=1$. Optimize the scalar damping in linear theory for each topology, then integrate the nonlinear equations from a period-one shooting state. This initialization avoids misinterpreting the slow decay of middle-only transients.
'''+fig('03_topology',r'\C Linear damping curves at $R=5,G=0.1$ and nonlinear confirmation dots at each linear optimum. Middle-only power remains small. Its 2.60\% nonlinear correction means it fails the stated 2\% power-agreement rule; it is labelled nonlinear rather than treated as a validated linear result.','67mm')+r'''
\begin{table}[H]\centering\small
\caption{\C Generator-placement confirmations; $\widehat P/G^2$ is nonlinear, evaluated at a linear damping maximum.}
\begin{tabular}{lrrrrr}\toprule
Topology&$R$&$G$&$\kappa$&$\widehat P/G^2$&power error\\\midrule
@TOPOTABLE@
\bottomrule\end{tabular}\end{table}
\D A double pendulum has two absolute rod velocities but its middle generator responds only to their difference. If both arms nearly follow the blade, that difference is small in absolute terms; it need not be small relative to the first arm's already-small deflection.
\begin{table}[H]\centering\small
\caption{\C Linear relative-amplitude audit at $G=0.01$, equal masses and rods, with both generators at their optimum.}
\begin{tabular}{rrrr}\toprule
$R$&$G$&$|z_2-z_1|/|z_1|$&$|z_2-z_1|/G$\\\midrule
@C12TABLE@
\bottomrule\end{tabular}\end{table}
\C The relative amplitude approaches about one-third, not zero. The middle-only/pivot-only optimal power ratio nevertheless falls from 0.0236 at $R=1.2$ to 0.000206 at $R=10$ ($G\to0$). A second joint is not a second independent energy supply.
''')
parts.append(r'''\page{Mass distribution and similarity}
\A A separate dimensionless slice holds $R=1.2$, $G=0.01$, $M$ and $L$ fixed while varying $\mu\in\{0.01,0.1,1\}$ and $\lambda_\ell\in\{0.1,0.316,1\}$. Each double uses both generators at its linear-optimal damping; each power is confirmed with a nonlinear run.
'''+fig('04_geometry_ratios',r'\C Nonlinear double power divided by the matched linear single optimum for the nine geometries, all at $R=1.2,G=0.01$. The single is itself in the weak-forcing limit; this plot does not imply a general optimum at other forcing strengths.','67mm')+r'''
\C The best sampled geometry is $\mu=1$, $\lambda_\ell=0.1$: $\kappa=@GEOK@$ and $\overline{\widehat P}=@GEOP@$. The nine geometries remain below the matched single optimum. The rotor mapping used for this dimensionless stress test is a coordinate conversion, not an additional selected turbine mounting.

\D In the heavy-first-mass limit $\mu\to0$, the second mass contributes little inertia or forcing. The result approaches a heavy pendulum at reach $l_1$, not at the full reach $L$. Comparing it to a mass at $L$ without noting this difference would change the physical question.

\D Similarity follows because the differential equations depend only on dimensionless parameters. Scale every mass by $3$, every rod and pivot radius by $4$, angular speed by $1/2$, and damping by $24$. With unchanged $g$, $R,G,\mu,\lambda_\ell,\kappa_i$ remain fixed. Thus
\begin{equation}
\frac{P_{h,\rm new}}{P_{h,\rm old}}=
\frac{(3M)(4L)^2(\Omega/2)^3}{ML^2\Omega^3}=6.
\end{equation}
\C The test gives a power ratio @SIMRATIO@ and a maximum dimensionless state difference @SIMERR@ at relative tolerance $10^{-10}$ and absolute tolerance $10^{-12}$. The state difference depends on tolerance and floating-point arithmetic; it is not a universal similarity constant. Scaling only total mass or total rod length while changing their internal ratios would not preserve the model.
''')
parts.append(r'''\page{Chaos and the matched power comparison}
\A The original scan has 48 combinations of $\Omega\in\{2,4,6\}$ rad/s, $r_p\in\{0.05,0.20\}$ m, and eight dampings, plus six refinements. It deliberately probes forcing outside the corrected blade-fraction mappings. Mixing powers between different $G$ values would confound chaos with a change in forcing.

\D Benettin's test evolves a nearby trajectory at fixed forcing phase. Every quarter period, its separation is renormalized to $\epsilon$ in the $(q_1,q_2,u_1,u_2)$ norm. The conditional exponent is
\begin{equation}
\widehat\Lambda=\frac1{\Delta s}\sum_j\log\frac{\|\delta\mathbf x_j\|}{\epsilon},\qquad\Lambda=\Omega\widehat\Lambda.
\end{equation}
\A A nonperiod-one candidate is called chaotic only if $\widehat\Lambda>0.002$ and all four 50-period exponent blocks are positive, after 8 alignment periods. Period-one trajectories use a shorter 24-period stability check. ``Regular'' means the chaos criterion was not met; it does not mean that periodicity has been proved.
'''+fig('05_chaos',r'\C Left: the matched $R=1,G=3.065$ group, with damping varied. Right: all 54 computed cases, whose forcing differs; the vertical line alone is not the complete chaos criterion.','58mm')+r'''
\C This rerun finds @COUNT@ chaotic cases. The historical claim of four cannot be recovered from the lite attachment and is not repeated as a measured fact. Classification is finite-time and can change with basin, window and numerical perturbations.
\begin{table}[H]\centering\small
\caption{\C Matched 200-period power windows, after 200 discarded periods. $R=1,G=3.065$, equal masses and rods. Errors are naive block standard errors, not rigorous confidence intervals.}
\begin{tabular}{lrrrrr}\toprule
Orbit&$R$&$G$&$\kappa$&$P_h$ (W)&$\widehat\Lambda$\\\midrule
Regular&1&3.065&1.375&0.3789&$-0.1504$\\
Chaotic&1&3.065&1.875&$@CP@\pm@CSE@$&$@CL@\pm@CLSE@$\\\bottomrule
\end{tabular}\end{table}
\C The original fragments quoted 0.244 W and $\widehat\Lambda=0.0358$ for the chaotic case. The present short window differs because chaotic trajectories are sensitive to arithmetic and implementation; the longer test below is the appropriate basis for the approximate 0.244 W comparison. Fine digits do not represent physical certainty.
''')
parts.append(r'''\page{Longer windows and basin checks}
\C The supplied robustness metadata tested the older regular orbit at $c=0.010$ N m s/rad, not the headline $c=0.022$ orbit. The present long and alternate-start runs explicitly use the headline regular and chaotic pair.
'''+fig('06_sections',r'\C Fixed-phase sections after tangent alignment, $R=1,G=3.065$. The regular case collapses to a point; the chaotic case has a spread of states. The axes use relative blade coordinates.','55mm')+r'''
\begin{table}[H]\centering\small
\caption{\C Robustness runs at $R=1,G=3.065$; all discard 400 periods. L averages 800 periods; B0 and B1 average 400 from alternate starts.}
\begin{tabular}{lrrrrr}\toprule
Run&$R$&$G$&periods&$P_h$ (W)&$\widehat\Lambda$\\\midrule
@ROBUSTTABLE@
\bottomrule\end{tabular}\end{table}
\C The long chaotic mean is $@LP@\pm@LSE@$ W using sixteen 50-period blocks. The block standard deviation is @LSD@ W. Block autocorrelation and deterministic chaos prevent treating that naive standard error as a rigorous confidence interval. The long chaotic/regular mean ratio is @LRATIO@.

\C Two 400-period exponent checks start from the same explicitly recorded checkpoint and forcing phase, with separation $10^{-6}$ and $10^{-7}$. They give $\widehat\Lambda=@EPS1@$ and @EPS2@ respectively; every 100-period block is positive. The sign is robust in these tests, while the magnitude retains finite-time variability.

\D Damping changes both the trajectory and the work drawn from the rotor. Larger irregular velocity fluctuations do not, by themselves, imply more power at the best damping. The tested regular branch wins against the tested chaotic branch; neither has been exhaustively optimized over all possible initial conditions, damping coefficients and generator models.
''')
parts.append(r'''\page{Sensor power and acceleration limits}
\D ADXL362 Rev. G states a typical 1.8 $\mu$A at 100 Hz and 2.0 V. CC2652R SWRS207J gives 7.0 mA transmitting at the setting named 0 dBm (1 mW RF output), 3.39 mA for the active 48 MHz core, and 0.94 $\mu$A standby, at 3.0 V with the specified DC/DC configuration [1,2].
\A Continuously sense at 100 Hz; each second transmit for 1 ms and process for 1 ms, with standby for the remaining 998 ms. A 1 Mbit/s air rate and 1000 total on-air bits per event are assumed. Send a feature packet, not every raw tri-axis sample. Supply rails are treated at their datasheet test voltages.
\begin{table}[H]\centering\small
\caption{\D Typical-current reference budget. Schedules, packet length and voltage implementation are Assumed.}
\begin{tabular}{lrr}\toprule
Component&duty fraction&mean power ($\mu$W)\\\midrule
Continuous accelerometer&1&3.60\\
Radio transmission&0.001&21.00\\
Active CPU&0.001&10.17\\
Standby&0.998&2.814\\\midrule
Total&&@BUDGET@\\\bottomrule\end{tabular}\end{table}
\D At assumed efficiency $\eta=0.5$, the mechanical requirement is @MECHBUDGET@ $\mu$W. Startup, reception, retries, bus peripherals, memory, converter leakage and storage losses are excluded. This is a sourced reference load, not a guaranteed complete-node consumption figure. \A A separate 1 mW electrical planning allowance can cover uncharacterized overhead, but that allowance is not a datasheet result.
'''+fig('07_sensor_range',r'\D Peak radial specific-force envelope $g(\Gamma+1)$ at the pivot, assuming a radial sensor axis and no additional vibration. The range line is the ADXL362 maximum setting.','48mm')+r'''
\D A blade-fixed accelerometer measures specific force, including the gravity projection. For a radial axis the worst value is $(\Omega^2r_p+g)$, so $\Gamma<7$ is a conservative gravity-only condition for an 8$g$ range. Six slow-rotor mountings pass it; all nine fast-rotor mountings fail. The remaining slow cases are marginal or exceed range before vibration is added.

\C Corrected centrifugal acceleration alone spans @GAMMIN@--@GAMMAX@ times $g$. The specified accelerometer is therefore a power reference at many mountings; adequate power does not make it a usable radial sensor there. A higher-range device needs its own sourced budget and bandwidth/noise assessment.
''')
parts.append(r'''\page{Numerical checks and reproducibility}
\C The initial anchor integrations used unmodified SciPy DOP853, before any study changes. The original model files remain byte-for-byte in \texttt{code/reference/}. The third exponent check took 1.09 s in addition to its power integration.
\begin{table}[H]\centering\small
\caption{\C Initial reference anchors; timing is local wall time, not a portable performance guarantee.}
\begin{tabular}{lrrrr}\toprule
Anchor&$R$&$G$&result&wall time (s)\\\midrule
Single&2.5&0.4471&0.151801057623 W&1.52\\
Double&2.5&0.4471&0.101284543458 W&16.51\\
Matched regular&1&3.065&$\widehat P=1.480157448$&9.45\\\bottomrule
\end{tabular}\end{table}
\C The double anchor rounds to 0.101285 W, but its relative difference from that printed decimal is $4.51\times10^{-6}$. A strict $10^{-6}$ comparison against a six-decimal reference is inconsistent with its rounding precision. Work paused on this explicit stop condition; following the user's instruction to complete the objective, the rounding interval was documented and accepted. It is a reference-format issue, not an equation change.

\A DOP853 uses relative tolerance $10^{-10}$, absolute tolerance $10^{-12}$, and maximum step 0.20 in $s$. Power and rotor work are integrated as states, rather than estimated from sparse saved samples. Most runs discard 100 and average 200 periods; chaos uses 200/200 and robustness 400/400 or 400/800. The original opt-in local C stage kernel accelerates the unchanged SciPy tableau; it installs nothing and makes no network request.

\C The energy residual is
\begin{equation}
\epsilon_E=\frac{|W_{\rm rotor}-H-\Delta E|}{|H|}.
\end{equation}
\C The largest residual among the 111 nonlinear runs is @MAXBAL@. A separate centred finite-difference identity check at random states has maximum normalized error @EIDENT@. These checks test the ideal equations, not the omitted physical losses.

\C The retained original RK4 outputs at 2048 and 4096 steps/period differ by @RK1@ and @RK2@ in relative mean power. Both meet the explicitly selected $10^{-8}$ threshold. Their arithmetic was rechecked; these long RK4 integrations were not redundantly rerun.

\C \texttt{code/README.md} gives exact commands and installed package versions. \texttt{summary.csv} contains 111 nonlinear runs and 49 linear evaluations with the requested fields plus dimensionless coordinates. Unmeasured exponents are NaN and the regime is ``not measured'', including all corrected mappings without exponent measurements. Saved trajectories are float32, with 16 samples per rotor period; calculations remain float64.
''')
parts.append(r'''\page{Correction audit and primary sources}
\C The following is an audit of C1--C14, distinguishing verified calculations from historical statements that cannot be reconstructed from absent files.
\renewcommand{\arraystretch}{1.22}
\par\medskip\noindent\begin{tabularx}{\textwidth}{@{}lX@{}}\toprule
Item&Verification and action\\\midrule
C1&Compact ZIP checked by file inventory and CRC; only selected float32 trajectories retained. The damaged original large archive is absent, so its historical damage cannot be independently inspected.\\
C2&Radius, tip-speed and turbine-power arithmetic verified. $C_p=0.45$ and $\lambda_T=7$ are scenario assumptions. The claim that a given $C_p$ universally requires a particular tip-speed interval is not established without a blade aerodynamic model.\\
C3&Three of six legacy pivots lie outside the corrected rotor. Replaced by 18 mountings with blade fractions 0.3, 0.6 and 0.9.\\
C4&Primary datasheet confirms the 8$g$ limit. Recomputed acceleration and included the gravity projection.\\
C5&Five unfinished legacy exponents are explicitly ``not measured''; their identities and $R,G$ are in \texttt{audit.json}.\\
C6&Original classification code inspected; all 54 cases rerun, @COUNT@ meet the criterion. Lost survivor-count details are not independently verifiable.\\
C7&Original four block values are absent. New block statistics are computed, rounded, and labelled naive standard errors.\\
C8&Retained robustness JSON confirms the older regular source. Long and alternate-start checks now explicitly test the headline pair.\\
C9&Stored RK4 values give the stated tiny differences; an explicit $10^{-8}$ relative-power threshold is recorded.\\
C10&Original code uses three paired points per class. New study samples each speed at three blade fractions; continuous range coverage is not claimed.\\
C11&Two primary datasheets inspected and hashed. Typical-current budget derived from an explicit schedule; efficiency and overhead allowance remain assumptions.\\
C12&Complex linear amplitudes reproduce the quoted 0.26--0.33 relative middle motion. Rewritten interpretation separates relative size from absolute size.\\
C13&$R,G$, topology, source and the meaning of $\Gamma,\mu,\lambda_\ell$ are explicit. Middle-only nonlinear correction is retained and labelled.\\
C14&All individual masses and rods scale uniformly. Power factor six reproduced, with the numerical state error and solver tolerances stated.\\\bottomrule
\end{tabularx}
\renewcommand{\arraystretch}{1}
\subsection*{Primary sources}
\D [1] Analog Devices, \emph{ADXL362}, Rev. G, May 2023, specifications on pp. 4--5. Accessed 14 October 2026.\par
\url{https://www.analog.com/media/en/technical-documentation/data-sheets/adxl362.pdf}

\D [2] Texas Instruments, \emph{CC2652R}, SWRS207J, revised November 2023, sections 8.5--8.6, pp. 10--11. Accessed 14 October 2026.\par
\url{https://www.ti.com/lit/ds/symlink/cc2652r.pdf}

\C Full SHA-256 values, source conditions and font provenance are in \texttt{sources/README.md}. Datasheet PDFs are deliberately excluded. The report is reconstructed from the supplied code, manifest, fragments and new computations; no absent original report has been treated as evidence.
''')
parts.append(r'''\page{Verdict: sufficient power, conditional usefulness}
\C The ideal mechanical result is favourable for a very small local load: the selected single pendulum supplies @SMIN@--@SMAX@ mW at the corrected mountings. At assumed 50\% conversion, the output is @EMIN@--@EMAX@ mW, versus a @BUDGET@ $\mu$W typical-current reference. Even the separate assumed 1 mW planning load is below these ideal outputs. The numerical model therefore supports power sufficiency for the stated duty cycle, not a hardware reliability claim.

\D Every harvested joule is supplied by the rotor after accounting for mechanical storage. For the best corrected point, ideal harvest is @BESTF@ of the assumed turbine power. Real aerodynamic drag, friction and regulation can increase the cost. This device is not worth building to raise turbine efficiency or net turbine electricity.

\C There is no demonstrated reason here to prefer a chaotic double pendulum. The equal-mass, equal-reach double loses at all 18 corrected mountings. At the matched nonlinear forcing $R=1,G=3.065$, the regular branch supplies about 0.379 W, while the longer chaotic window supplies about 0.244 W. The latter fluctuates with averaging window and initial condition. Added hinges, wiring and moving components would need to earn their complexity through a separately demonstrated benefit.

\A A prototype is conditionally worth considering only as a local sensor supply where wiring, rotating power transfer or battery servicing is sufficiently costly. The first candidate should be the mechanically simpler single pendulum. Use a slow-rotor mounting that meets the accelerometer range with vibration margin, or select and budget a suitable higher-range sensor. Assume no extra turbine output and no safety credit from the ideal calculations.

\A Before committing to a blade installation, the generator must produce the assumed near-viscous braking torque at the actual joint speeds, overcome its own electrical threshold, and deliver useful power after leakage and storage losses. The available electrical margin should be measured with the full sampling, radio startup, reception and retry schedule. Cold start and a still-air interval require an explicit storage design.

\A The attachment must also tolerate centrifugal loading, vibration, fatigue and rotor imbalance; keep the entire swept pendulum and enclosure within the blade's available envelope; and prevent a detached mass becoming a hazard. The fixed-$\Omega$, zero-aerodynamic-drag model provides none of these qualifications. The point-mass, massless-rod approximation omits the hardware mass that may dominate such a small generator.

\D The deciding experiment is a blade-equivalent rotating rig: measure joint torque and speed, rotor reaction work, net regulated electrical energy, sensor saturation, and startup/storage behaviour under the intended duty cycle. If wiring or a maintained battery is cheaper and more reliable, reject this mechanism. If local autonomy offsets the mechanical burden and the measured energy margin survives those tests, a single-pendulum supply is plausible. The present study justifies that narrow engineering trial; it does not justify a turbine retrofit or a chaos-based power claim.
\end{document}
''')
text='\n'.join(parts)
invalid=[r for r in M if not r['linear_valid']]
inv='\n'.join(' & '.join([('S' if r['single'] else 'D')+f", {r['Omega_rad_s']:.3f} rad/s, {r['r_p_m']/r['R_rotor_m']:.1f}",n(r['R_nd'],4),n(r['G_nd'],4),n(r['c_N_m_s_per_rad'],4),n(r['peak_q_rad'],4)])+r' \\' for r in sorted(invalid,key=lambda r:r['name']))
top='\n'.join(' & '.join([r['name'].split('_')[-1],n(r['R_nd']),n(r['G_nd']),n(r['kappa'],5),n(r['P_hat']/r['G_nd']**2,5),f"{100*r['linear_relative_power_error']:.3f}\\%"])+r' \\' for r in nl if r['study']=='topology')
c12='\n'.join(f"{r['R_nd']:g} & {r['G_nd']:g} & {r['middle_over_first_amplitude']:.3f} & {r['middle_amplitude_per_G']:.4f}"+r' \\' for r in audit['C12'])
rob='\n'.join(' & '.join([r['name'].replace('robust_','').replace('_long',' L').replace('_basin0',' B0').replace('_basin1',' B1'),n(r['R_nd']),n(r['G_nd'],4),str(r['average_periods']),n(r['mean_power_W'],4),n(r['lyapunov']['lambda_dimensionless'],3)])+r' \\' for r in nl if r['study']=='robustness')
geobest=max([r for r in nl if r['study']=='geometry'],key=lambda r:r['mean_power_W'])
vals=dict(SMIN=n(min(r['mean_power_W'] for r in S)*1000,3),SMAX=n(best['mean_power_W']*1000,3),RMIN=n(min(rat),4),RMAX=n(max(rat),4),BUDGET=n(audit['sensor']['total_W']*1e6,5),MECHBUDGET=n(audit['sensor']['required_mechanical_W']*1e6,5),SMALLTABLE=table_map('small'),LARGETABLE=table_map('large'),BEST=n(best['mean_power_W']*1000,4),BESTO=n(best['Omega_rad_s'],5),BESTRP=n(best['r_p_m'],4),BESTR=n(best['R_nd'],4),BESTG=n(best['G_nd'],4),BESTT=n(best['turbine_output_W'],5),BESTF=f"${best['mean_power_W']/best['turbine_output_W']:.3g}$",INVALIDTABLE=inv,TOPOTABLE=top,C12TABLE=c12,GEOK=n(geobest['kappa'],4),GEOP=f"{geobest['P_hat']:.4g}",SIMRATIO=n(audit['similarity']['power_ratio'],12),SIMERR=f"${audit['similarity']['dimensionless_trajectory_max_abs']:.3g}$",COUNT=str(sum(r['regime']=='chaotic' for r in ch)),CP=f"{cha['mean_power_W']:.3f}",CSE=f"{np.std(cha['block_power_W'],ddof=1)/2:.3f}",CL=f"{cha['lyapunov']['lambda_dimensionless']:.3f}",CLSE=f"{np.std(cha['lyapunov']['blocks'],ddof=1)/2:.3f}",ROBUSTTABLE=rob,LP=f"{long['mean_power_W']:.3f}",LSE=f"{np.std(long['block_power_W'],ddof=1)/4:.3f}",LSD=f"{np.std(long['block_power_W'],ddof=1):.4f}",LRATIO=n(long['mean_power_W']/reg['mean_power_W'],4),EPS1=f"{eps['results'][0]['lambda_dimensionless']:.3f}",EPS2=f"{eps['results'][1]['lambda_dimensionless']:.3f}",GAMMIN=n(min(r['Gamma'] for r in M),4),GAMMAX=n(max(r['Gamma'] for r in M),4),MAXBAL=f"${max(r['energy_balance_rel_err'] for r in nl):.3g}$",EIDENT=f"${audit['energy_identity_finite_difference_max_normalized_error']:.3g}$",RK1=f"${audit['rk4'][0]['relative_power_difference']:.3g}$",RK2=f"${audit['rk4'][1]['relative_power_difference']:.3g}$",EMIN=n(min(r['mean_power_W'] for r in S)*500,3),EMAX=n(best['mean_power_W']*500,3))
for k,v in vals.items():text=text.replace('@'+k+'@',v)
# Scientific notation rendered as proper mathematical powers.
import re
text=re.sub(r'(?<![A-Za-z])([0-9]+(?:\.[0-9]+)?)e([+-][0-9]+)',lambda m:r'\ensuremath{'+m[1]+r'\times10^{'+str(int(m[2]))+'}}',text)
(ROOT/'report.tex').write_text(text)
print('report.tex written; planned 14 pages')
