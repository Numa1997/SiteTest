"""Generate every report figure as SVG and PDF, using included IBM Plex fonts."""
import sys,json
from pathlib import Path
from dataclasses import replace
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager as fm
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'code'))
from compute import Parameters,optimum,linear_power
sans=fm.FontProperties(fname=str(ROOT/'fonts/IBMPlexSans-Regular.otf'))
mono=fm.FontProperties(fname=str(ROOT/'fonts/IBMPlexMono-Regular.otf'))
for f in [sans,mono]:fm.fontManager.addfont(f.get_file())
plt.rcParams.update({'font.family':sans.get_name(),'font.size':10,'axes.labelsize':10,'legend.fontsize':9,'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','pdf.fonttype':42,'figure.facecolor':'white','axes.facecolor':'white','axes.edgecolor':'#4a413d','axes.labelcolor':'#1c1518','xtick.color':'#4a413d','ytick.color':'#4a413d','text.color':'#1c1518','savefig.facecolor':'white'})
MAIN='#7a1f2b';COMP='#4a413d';REF='#1c1518';FAINT='#8b8079'
rows=json.loads((ROOT/'data/all_results.json').read_text());nl=[r for r in rows if r['source']=='nonlinear'];by={r['name']:r for r in nl}

def save(fig,name):
 for ax in fig.axes:
  for t in ax.get_xticklabels()+ax.get_yticklabels():t.set_fontproperties(mono);t.set_fontsize(8)
  ax.grid(alpha=.13,color=FAINT)
 for ext in ['svg','pdf']:fig.savefig(ROOT/'figures'/f'{name}.{ext}',bbox_inches='tight')
 plt.close(fig)

def main():
 fig,ax=plt.subplots(figsize=(6.5,3.7));ax.set_aspect('equal');ax.axis('off')
 s=.5;theta1=-.2;theta2=-1.0;rp=1.1;l1=.65;l2=.5
 pivot=rp*np.array([np.cos(s),np.sin(s)]);x1=pivot+l1*np.array([np.cos(theta1),np.sin(theta1)]);x2=x1+l2*np.array([np.cos(theta2),np.sin(theta2)])
 circ=plt.Circle((0,0),rp,fill=False,ls='--',color=FAINT,lw=1);ax.add_patch(circ)
 ax.plot([0,pivot[0]],[0,pivot[1]],color=COMP,lw=6,alpha=.6)
 ax.plot([pivot[0],x1[0],x2[0]],[pivot[1],x1[1],x2[1]],color=MAIN,lw=2)
 ax.scatter([0,pivot[0],x1[0],x2[0]],[0,pivot[1],x1[1],x2[1]],s=[30,60,110,110],color=[REF,COMP,MAIN,MAIN])
 ax.text(-.15,-.2,'hub');ax.text(pivot[0]-.25,pivot[1]+.14,'pivot: Ωt');ax.text(x1[0]+.05,x1[1]+.05,'m₁');ax.text(x2[0]+.05,x2[1]-.03,'m₂')
 ax.text(pivot[0]/2-.08,pivot[1]/2+.12,'r_p');ax.text((pivot[0]+x1[0])/2,(pivot[1]+x1[1])/2+.1,'l₁');ax.text((x1[0]+x2[0])/2+.1,(x1[1]+x2[1])/2,'l₂')
 ax.annotate('',xy=(2.25,-.2),xytext=(2.25,.5),arrowprops=dict(arrowstyle='->',color=REF));ax.text(2.34,.08,'g')
 ax.text(-1.08,.83,'Rotor plane; absolute rod angles θ₁, θ₂');ax.text(-1.08,.64,'Joint speeds: θ̇₁ − Ω and θ̇₂ − θ̇₁')
 ax.set_xlim(-1.2,2.65);ax.set_ylim(-.6,1.1);save(fig,'01_geometry')
 fig,axs=plt.subplots(1,2,figsize=(7,3.25),sharey=True)
 for ax,grp in zip(axs,['small','large']):
  for frac,marker in [(30,'o'),(60,'s'),(90,'^')]:
   for topo,color,ls in [('single',MAIN,'-'),('both',COMP,'--')]:
    rr=sorted([r for r in nl if r['name'].startswith('map_'+grp+'_') and r['name'].endswith('_'+topo) and r['name'].split('_')[-2]==str(frac)],key=lambda r:r['Omega_rad_s'])
    ax.plot([r['Omega_rad_s'] for r in rr],[1000*r['mean_power_W'] for r in rr],marker=marker,color=color,ls=ls,label=f'{topo}, r_p/R_rot = {frac/100:.1f}')
  ax.set_xlabel('Angular speed Ω (rad/s)');ax.set_title(grp.capitalize()+' rotor mapping')
 axs[0].set_ylabel('Mean mechanical harvest (mW)');axs[1].legend(fontsize=7,ncol=1,frameon=False)
 fig.tight_layout();save(fig,'02_mapping_power')
 fig,ax=plt.subplots(figsize=(6.8,3.1));O=np.sqrt(9.80665/(.2*.1));ks=np.logspace(-2,2,230)
 styles={'single':(REF,'--'),'both':(MAIN,'-'),'pivot':(COMP,'-'),'middle':(FAINT,':')}
 for topo in ['single','both','pivot','middle']:
  color,ls=styles[topo];p=Parameters(Omega=O,rp=1.,single=topo=='single',mode='pivot' if topo=='single' else topo)
  ys=[linear_power(replace(p,c=k*p.M*p.L**2*p.Omega))/(p.M*p.L**2*p.Omega**3*.1**2) for k in ks]
  ax.loglog(ks,ys,color=color,ls=ls,label=topo+' (linear)')
  r=by['topology_'+topo];ax.scatter([r['kappa']],[r['P_hat']/r['G_nd']**2],s=28,color=color)
 ax.set_xlabel('Damping κ');ax.set_ylabel('Power P̂/G²');ax.legend(ncol=2,frameon=False);fig.tight_layout();save(fig,'03_topology')
 fig,ax=plt.subplots(figsize=(6.3,3.1));geom=[r for r in nl if r['study']=='geometry'];mus=[.01,.1,1.];ls=[.1,.316227766,1.]
 p=optimum(Parameters(Omega=np.sqrt(9.80665/(.2*.01)),rp=.24,single=True,mode='pivot'));den=linear_power(p)
 vals=np.array([[next(r['mean_power_W'] for r in geom if r['mu']==mu and abs(r['length_ratio']-lam)<1e-8)/den for lam in ls] for mu in mus])
 from matplotlib.colors import LinearSegmentedColormap
 im=ax.imshow(vals,cmap=LinearSegmentedColormap.from_list('result',['#ffffff',MAIN]),vmin=0,vmax=1,aspect='auto')
 ax.set_xticks(range(3),['0.1','0.316','1']);ax.set_yticks(range(3),['0.01','0.1','1']);ax.set_xlabel('Rod-length ratio ℓ₂/ℓ₁');ax.set_ylabel('Mass ratio m₂/m₁')
 for i in range(3):
  for j in range(3):ax.text(j,i,f'{vals[i,j]:.3f}',ha='center',va='center',color='white' if vals[i,j]>.5 else REF)
 cb=fig.colorbar(im,ax=ax);cb.set_label('Nonlinear double / linear single power');fig.tight_layout();save(fig,'04_geometry_ratios')
 fig,axs=plt.subplots(1,2,figsize=(7,3.05))
 ch=[r for r in nl if r['study']=='chaos_scan'];group=sorted([r for r in ch if abs(r['R_nd']-1)<1e-9 and abs(r['G_nd']-9.80665/(16*.2))<1e-9],key=lambda r:r['kappa'])
 for reg,color,mark in [('regular',COMP,'o'),('chaotic',MAIN,'s')]:
  rr=[r for r in group if r['regime']==reg];axs[0].scatter([r['kappa'] for r in rr],[r['mean_power_W'] for r in rr],color=color,marker=mark,label=reg)
  rr=[r for r in ch if r['regime']==reg];axs[1].scatter([r['lyapunov']['lambda_dimensionless'] for r in rr],[r['P_hat'] for r in rr],color=color,marker=mark,s=25,alpha=.8)
 axs[0].set_xscale('log');axs[0].set_xlabel('Damping κ (R = 1, G = 3.065)');axs[0].set_ylabel('Mean harvest (W)');axs[0].legend(frameon=False)
 axs[1].axvline(.002,color=REF,ls='--',lw=1);axs[1].set_xlabel('Finite-time exponent Λ̂ (all 54 cases)');axs[1].set_ylabel('Dimensionless mean power P̂')
 fig.tight_layout();save(fig,'05_chaos')
 fig,axs=plt.subplots(1,2,figsize=(7,3.05))
 for ax,name,label,color in zip(axs,['robust_regular_long','robust_chaotic_long'],['Regular, κ = 1.375','Chaotic, κ = 1.875'],[COMP,MAIN]):
  z=np.load(ROOT/'data/runs'/f'{name}.npz');pts=z['lyapunov_poincare'];q=(pts[:,0]+np.pi)%(2*np.pi)-np.pi
  ax.scatter(q,pts[:,2],s=7,color=color,alpha=.6);ax.set_xlabel('Wrapped q₁ (rad)');ax.set_ylabel('u₁ = dq₁/ds');ax.set_title(label)
 fig.tight_layout();save(fig,'06_sections')
 fig,ax=plt.subplots(figsize=(6.8,3.2))
 for grp,marker in [('small','o'),('large','s')]:
  rr=[r for r in nl if r['study']=='corrected_mapping' and r['single'] and r['name'].startswith('map_'+grp)]
  for frac,color in [(30,MAIN),(60,COMP),(90,FAINT)]:
   ss=sorted([r for r in rr if r['name'].split('_')[-2]==str(frac)],key=lambda r:r['Omega_rad_s'])
   ax.plot([r['Omega_rad_s'] for r in ss],[r['Gamma']+1 for r in ss],marker=marker,color=color,label=f'{grp}, r_p/R_rot = {frac/100:.1f}')
 ax.axhline(8,color=REF,ls='--',label='ADXL362 ±8 g range');ax.set_xscale('log');ax.set_yscale('log');ax.set_xlabel('Angular speed Ω (rad/s)');ax.set_ylabel('Peak radial specific force / g (Γ + 1)');ax.legend(fontsize=8,ncol=2,frameon=False);fig.tight_layout();save(fig,'07_sensor_range')
if __name__=='__main__':main()
