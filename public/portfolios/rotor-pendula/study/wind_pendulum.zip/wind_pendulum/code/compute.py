"""Corrected finite study. No network access; no package installation.
Run from the archive root: OPENBLAS_NUM_THREADS=1 PENDULUM_NATIVE=1 python code/compute.py --workers 6
"""
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','1')
os.environ.setdefault('OMP_NUM_THREADS','1')
import sys,json,csv,time,argparse
from pathlib import Path
from dataclasses import asdict,replace
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np
from scipy.integrate import solve_ivp
from scipy.optimize import minimize_scalar,root
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'code/reference'))
from model import Parameters,System,integrate,linear_power,RTOL,ATOL
from lyapunov import benettin
G0=9.80665

def amplitudes(p):
 if p.single:
  return np.repeat(-p.M*p.L*p.g/(p.M*p.L*p.rp*p.Omega**2-p.M*p.L**2*p.Omega**2+1j*p.Omega*p.c0),2)
 A=p.M*p.l1**2;B=p.m2*p.l2**2;D=p.m2*p.l1*p.l2
 mass=np.array([[A,D],[D,B]])
 K=p.Omega**2*np.array([[p.M*p.l1*p.rp+D,-D],[-D,p.m2*p.l2*p.rp+D]])
 C=np.array([[p.c0+p.c1,-p.c1],[-p.c1,p.c1]])
 return np.linalg.solve(K-p.Omega**2*mass+1j*p.Omega*C,-p.g*np.array([p.M*p.l1,p.m2*p.l2]))

def optimum(p):
 scale=p.M*p.L*p.Omega*max(p.rp,p.L)
 opt=minimize_scalar(lambda z:-linear_power(replace(p,c=scale*np.exp(z))),bounds=(-12,8),method='bounded',options={'xatol':1e-9})
 return replace(p,c=float(scale*np.exp(opt.x)))

def periodic_state(p):
 a=amplitudes(p);start=np.r_[a.real,-a.imag]
 def end(x):
  sol=solve_ivp(System(p).rhs4,[0,2*np.pi],x,method='DOP853',rtol=RTOL,atol=ATOL,max_step=.2)
  if not sol.success:raise RuntimeError(sol.message)
  return sol.y[:,-1]
 if p.single:
  unpack=lambda v:np.array([v[0],v[0],v[1],v[1]])
  rr=root(lambda v:(end(unpack(v))-unpack(v))[[0,2]],start[[0,2]],tol=1e-9);x=unpack(rr.x)
 else:
  rr=root(lambda x:end(x)-x,start,tol=1e-9);x=rr.x
 error=float(np.max(abs(end(x)-x)))
 if error>1e-7:raise RuntimeError(f'Shooting residual {error}')
 return x,error

def local_nonlinear(p):
 def obj(z):
  pp=replace(p,c=p.c*np.exp(z));x,e=periodic_state(pp)
  sol=solve_ivp(System(pp).rhs,[0,2*np.pi],np.r_[x,0.,0.],method='DOP853',rtol=RTOL,atol=ATOL,max_step=.2)
  return -sol.y[4,-1]*pp.Omega/(2*np.pi)
 rr=minimize_scalar(obj,bounds=(-np.log(2),np.log(2)),method='bounded',options={'xatol':1e-5})
 return replace(p,c=float(p.c*np.exp(rr.x)))

def serial(r):
 return {k:(v.tolist() if isinstance(v,np.ndarray) else v) for k,v in r.items()}

def worker(job):
 name=job['name'];dest=ROOT/'data/runs'/f'{name}.json'
 if dest.exists():return json.loads(dest.read_text())
 p=Parameters(**job['parameters']);start=time.perf_counter()
 x0=np.array(job.get('x0',[.03,-.02,0.,0.]));init='prescribed initial condition'
 if job.get('periodic_init'):
  x0,e=periodic_state(p);init=f'periodic shooting, residual {e:.3g}'
 n=job.get('periods',200);discard=job.get('discard',100)
 r=integrate(p,discard=discard,periods=n,x0=x0,samples=16)
 qpeak=float(np.max(abs(r['y'][:2])))
 lin=linear_power(p);rel=abs(r['mean_power']/lin-1) if lin else np.nan
 valid=qpeak<.3 and rel<.02
 optimum_kind=job.get('optimum_kind','specified damping')
 if job.get('refine_invalid') and not valid:
  p=local_nonlinear(p);x0,e=periodic_state(p);init=f'periodic shooting, residual {e:.3g}'
  r=integrate(p,discard=discard,periods=n,x0=x0,samples=16)
  qpeak=float(np.max(abs(r['y'][:2])));lin=linear_power(p);rel=abs(r['mean_power']/lin-1);valid=qpeak<.3 and rel<.02
  optimum_kind='local nonlinear periodic-branch maximum; c bracket half to twice linear optimum'
 pts=r['y'][:4,::16].T
 dif=np.diff(pts[-51:],axis=0);dif[:,:2]=(dif[:,:2]+np.pi)%(2*np.pi)-np.pi
 pe=float(np.max(abs(dif)))
 lam=np.nan;reg='not measured';ly=None
 if job.get('measure_lyapunov'):
  per=24 if pe<1e-6 and not job.get('force_200') else job.get('lyapunov_periods',200)
  ly=benettin(p,r['y'][:4,-1],float(r['s'][-1]),periods=per)
  lam=ly['lambda_per_s'];reg='chaotic' if ly['lambda_dimensionless']>.002 and min(ly['blocks'])>0 else 'regular'
 Rrot=56/p.Omega
 out=dict(name=name,study=job['study'],source='nonlinear',parameters=asdict(p),Omega_rad_s=p.Omega,r_p_m=p.rp,R_rotor_m=Rrot,m1_kg=p.m1,m2_kg=p.m2,l1_m=p.l1,l2_m=p.l2,c_N_m_s_per_rad=p.c,mean_power_W=float(r['mean_power']),rotor_power_W=float(r['rotor_power']),energy_balance_rel_err=float(r['balance']),lyapunov_1_per_s=float(lam),regime=reg,generator_mode=p.mode,single=p.single,discard_periods=discard,average_periods=n,x0=x0.tolist(),initialization=init,block_power_W=r['blocks'].tolist(),storage_rate_W=float(r['storage_rate']),linear_power_W=float(lin),linear_relative_power_error=float(rel),peak_q_rad=qpeak,linear_valid=bool(valid),optimum_kind=optimum_kind,poincare_period1_error=pe,R_nd=p.rp/p.L,G_nd=p.g/(p.Omega**2*p.L),Gamma=p.Omega**2*p.rp/p.g,mu=p.m2/p.m1,length_ratio=p.l2/p.l1,kappa=p.c/(p.M*p.L**2*p.Omega),P_hat=r['mean_power']/(p.M*p.L**2*p.Omega**3),turbine_output_W=.5*1.225*np.pi*Rrot**2*8**3*.45,wall_seconds=time.perf_counter()-start,nfev=r['nfev'],solver='DOP853 native stage kernel' if os.environ.get('PENDULUM_NATIVE')=='1' else 'DOP853 Python',rtol=RTOL,atol=ATOL,samples_per_period=16)
 if ly:out['lyapunov']={k:v for k,v in ly.items() if k!='poincare'}
 # Float32 output only. Calculations and quadrature are float64.
 arrays=dict(t=r['s']/p.Omega,q=r['y'][:2].T,u=r['y'][2:4].T,P_harvest=r['power'],tau_on_rotor=r['tau'],H=r['y'][4],W_rotor=r['y'][5])
 if ly:arrays['lyapunov_poincare']=ly['poincare']
 np.savez_compressed(ROOT/'data/runs'/f'{name}.npz',**{k:np.asarray(v,dtype=np.float32) for k,v in arrays.items()})
 dest.write_text(json.dumps(out,indent=2,allow_nan=True));return out

def build_jobs():
 jobs=[]
 def add(name,study,p,**kw):jobs.append(dict(name=name,study=study,parameters=asdict(p),**kw))
 for group,rpms in [('small',[100,200,400]),('large',[8,14,20])]:
  for rpm in rpms:
   for frac in [.3,.6,.9]:
    for topo in ['single','both']:
     p=optimum(Parameters(Omega=rpm*2*np.pi/60,rp=frac*56/(rpm*2*np.pi/60),single=topo=='single',mode='pivot' if topo=='single' else 'both'))
     add(f'map_{group}_{rpm}_{int(frac*100)}_{topo}','corrected_mapping',p,refine_invalid=True,optimum_kind='linear damping maximum with nonlinear confirmation')
 manifest=json.loads((ROOT/'data/original_run_manifest.json').read_text())
 for m in manifest:
  if m['study']=='chaos':
   add(m['name'],'chaos_scan',Parameters(**m['parameters']),discard=m['discard'],periods=m['periods'],x0=m['x0'],measure_lyapunov=True)
 for topo in ['both','pivot','middle','single']:
  p=optimum(Parameters(Omega=np.sqrt(G0/(.2*.1)),rp=1.,single=topo=='single',mode='pivot' if topo=='single' else topo))
  add('topology_'+topo,'topology',p,periodic_init=True,optimum_kind='linear damping maximum, nonlinear at R_nd=5 G_nd=0.1')
 for mu in [.01,.1,1.]:
  for lam in [.1,.316227766,1.]:
   p=optimum(Parameters(Omega=np.sqrt(G0/(.2*.01)),rp=.24,m1=.1/(1+mu),m2=.1*mu/(1+mu),l1=.2/(1+lam),l2=.2*lam/(1+lam)))
   add(f'geometry_m{mu}_l{lam}','geometry',p,periodic_init=True,optimum_kind='linear damping maximum with nonlinear confirmation')
 # Required anchors repeated unmodified first; cached reference metadata also delivered.
 for name in ['small_o0_r0_single_opt','small_o0_r0_both_opt']:
  m=next(x for x in manifest if x['name']==name)
  add(name,'anchor',Parameters(**m['parameters']),discard=m['discard'],periods=m['periods'],x0=m['x0'])
 for label,c in [('regular',.022),('chaotic',.03)]:
  p=Parameters(Omega=4.,rp=.2,c=c)
  add('robust_'+label+'_long','robustness',p,discard=400,periods=800,x0=[1.2,-.8,0.,0.],measure_lyapunov=True,force_200=True,lyapunov_periods=400)
  for i,x in enumerate([[.03,-.02,0.,0.],[2.4,.7,-.5,.3]]):
   add('robust_'+label+'_basin'+str(i),'robustness',p,discard=400,periods=400,x0=x,measure_lyapunov=True,force_200=True)
 return jobs

def assemble():
 rows=[json.loads(p.read_text()) for p in sorted((ROOT/'data/runs').glob('*.json'))]
 linear=[]
 for r in rows:
  if r['study'] in ['corrected_mapping','geometry','topology']:
   z=r.copy();z.update(name=r['name']+'_linear',source='linear',mean_power_W=r['linear_power_W'],rotor_power_W=r['linear_power_W'],energy_balance_rel_err=np.nan,lyapunov_1_per_s=np.nan,regime='not measured',discard_periods=0,average_periods=0,peak_q_rad=float(max(abs(amplitudes(Parameters(**r['parameters']))))),P_hat=r['linear_power_W']/(sum([r['m1_kg'],r['m2_kg']])*(r['l1_m']+r['l2_m'])**2*r['Omega_rad_s']**3));linear.append(z)
 rows+=linear
 fields=['study','Omega_rad_s','r_p_m','R_rotor_m','m1_kg','m2_kg','l1_m','l2_m','c_N_m_s_per_rad','mean_power_W','rotor_power_W','energy_balance_rel_err','lyapunov_1_per_s','regime','source','name','generator_mode','single','R_nd','G_nd','Gamma','mu','length_ratio','kappa','P_hat','turbine_output_W','peak_q_rad','linear_relative_power_error','linear_valid','poincare_period1_error','discard_periods','average_periods']
 with (ROOT/'data/summary.csv').open('w') as f:
  w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(rows)
 (ROOT/'data/all_results.json').write_text(json.dumps(rows,indent=2))
 return rows

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--workers',type=int,default=6);ap.add_argument('--suite',choices=['all','maps','chaos','other'],default='all');a=ap.parse_args()
 jobs=build_jobs()
 if a.suite!='all':jobs=[j for j in jobs if (j['study']=='corrected_mapping' if a.suite=='maps' else j['study']=='chaos_scan' if a.suite=='chaos' else j['study'] not in ['corrected_mapping','chaos_scan'])]
 (ROOT/'data/corrected_manifest.json').write_text(json.dumps(build_jobs(),indent=2))
 with ProcessPoolExecutor(max_workers=a.workers) as pool:
  for f in as_completed([pool.submit(worker,j) for j in jobs]):
   r=f.result();print(r['name'],f"P={r['mean_power_W']:.8g}",r['regime'],f"balance={r['energy_balance_rel_err']:.2g}",flush=True)
 assemble()
