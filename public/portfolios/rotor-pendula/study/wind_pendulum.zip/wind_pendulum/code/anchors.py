"""Reproduce the three original anchors on the reference Python solver.
Run before compute.py if independently repeating the complete workflow.
"""
import os
os.environ['PENDULUM_NATIVE']='0'
import sys,json,time
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'code/reference'))
from model import Parameters,integrate
from lyapunov import benettin
manifest=json.loads((ROOT/'data/original_run_manifest.json').read_text());out=[]
for name,target in [('small_o0_r0_single_opt',.151801),('small_o0_r0_both_opt',.101285),('chaos_matched_refine_c1',1.48016)]:
 m=next(x for x in manifest if x['name']==name);p=Parameters(**m['parameters']);t=time.perf_counter()
 r=integrate(p,discard=m['discard'],periods=m['periods'],x0=m['x0'],samples=16)
 ph=r['mean_power']/(p.M*p.L**2*p.Omega**3)
 a=dict(name=name,wall_seconds=time.perf_counter()-t,power_W=r['mean_power'],P_hat=ph,balance=r['balance'])
 value=r['mean_power'] if name.startswith('small') else ph
 # User-directed continuation accepts the printed reference's rounding interval.
 allowance=(.5e-6 if name.startswith('small') else .5e-5)+1e-6*target
 if abs(value-target)>allowance:raise RuntimeError(f'Anchor outside rounding-aware tolerance: {value}, target {target}')
 if name.startswith('chaos'):
  t=time.perf_counter();b=benettin(p,r['y'][:4,-1],r['s'][-1],periods=24)
  a['lyapunov']={k:v for k,v in b.items() if k!='poincare'};a['lyapunov_wall_seconds']=time.perf_counter()-t
 out.append(a);print(a,flush=True)
(ROOT/'data/anchors_rerun.json').write_text(json.dumps(out,indent=2))
