"""Recompute arithmetic checks and source-derived node budget; no network."""
import sys,json
from pathlib import Path
from dataclasses import replace
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'code'))
from compute import Parameters,System,optimum,amplitudes,linear_power,integrate

def main():
 out={}
 # Arithmetic from retained first-delivery RK4 output, not a newly rerun RK4.
 rk=json.loads((ROOT/'data/original_rk4.json').read_text())
 checks=[]
 for name in sorted(set(r['name'] for r in rk)):
  a,b=sorted([r for r in rk if r['name']==name],key=lambda r:r['steps_per_period'])
  err=abs(a['mean_power_W']/b['mean_power_W']-1)
  checks.append(dict(name=name,relative_power_difference=err,acceptance_threshold=1e-8,passed=err<1e-8,status='recomputed arithmetic from retained original output'))
 out['rk4']=checks
 out['C12']=[]
 for R in [1.2,2.5,5.,10.]:
  p=optimum(Parameters(Omega=np.sqrt(9.80665/(.2*.01)),rp=R*.2))
  a=amplitudes(p)
  mid=optimum(replace(p,mode='middle'));piv=optimum(replace(p,mode='pivot'))
  out['C12'].append(dict(R_nd=R,G_nd=.01,kappa=p.c/(p.M*p.L**2*p.Omega),middle_over_first_amplitude=float(abs(a[1]-a[0])/abs(a[0])),middle_amplitude_per_G=float(abs(a[1]-a[0])/.01),middle_only_over_pivot_power=linear_power(mid)/linear_power(piv)))
 # Uniform scaling of every mass and every rod preserves all dimensionless parameters.
 manifest=json.loads((ROOT/'data/original_run_manifest.json').read_text())
 m=next(x for x in manifest if x['name']=='small_o0_r0_both_opt');p=Parameters(**m['parameters'])
 b=integrate(p,100,200,m['x0'],samples=16)
 p2=replace(p,m1=p.m1*3,m2=p.m2*3,l1=p.l1*4,l2=p.l2*4,Omega=p.Omega/2,rp=p.rp*4,c=p.c*24)
 z=integrate(p2,100,200,m['x0'],samples=16)
 out['similarity']=dict(power_ratio=z['mean_power']/b['mean_power'],predicted_ratio=6.,dimensionless_trajectory_max_abs=float(np.max(abs(z['y'][:4]-b['y'][:4]))),rtol=1e-10,atol=1e-12,all_masses_scale=3,all_rods_scale=4)
 # Check the energy identity along random states with centred numerical derivatives.
 rng=np.random.default_rng(20261014);errors=[]
 for single in [False,True]:
  pp=Parameters(Omega=4,rp=.2,c=.022,single=single,mode='pivot' if single else 'both');ss=System(pp)
  for _ in range(20):
   s=float(rng.uniform(0,2*np.pi));x=rng.normal(size=4)
   if single:x[[1,3]]=x[[0,2]]
   v=ss.rhs4(s,x);h=1e-5
   dEds=(ss.energy(s+h,x+h*v)-ss.energy(s-h,x-h*v))/(2*h)
   pow,tau=ss.observables(s,x);rhs=-tau-pow/pp.Omega
   errors.append(abs(dEds-rhs)/max(1.,abs(dEds),abs(rhs)))
 out['energy_identity_finite_difference_max_normalized_error']=max(errors)
 # Typical current figures at their specified supply voltages; times are design assumptions.
 budget=[dict(component='ADXL362 continuous sensing, 100 Hz',voltage_V=2.,current_A=1.8e-6,duty=1.,status='Derived from Rev. G typical current; schedule Assumed'),dict(component='CC2652R transmit 0 dBm, 1 ms each second',voltage_V=3.,current_A=7e-3,duty=.001,status='Derived from SWRS207J typical current; schedule Assumed'),dict(component='CC2652R CPU 48 MHz, 1 ms each second',voltage_V=3.,current_A=3.39e-3,duty=.001,status='Derived from SWRS207J section 8.5; schedule Assumed'),dict(component='CC2652R standby for remaining 998 ms',voltage_V=3.,current_A=.94e-6,duty=.998,status='Derived from SWRS207J typical current; schedule Assumed')]
 for r in budget:r['mean_power_W']=r['voltage_V']*r['current_A']*r['duty']
 out['sensor']=dict(components=budget,total_W=sum(r['mean_power_W'] for r in budget),conversion_efficiency=.5,required_mechanical_W=sum(r['mean_power_W'] for r in budget)/.5,radio_bits_per_event_assumed=1000,radio_data_rate_bits_per_s_assumed=1e6,comment='Assumed 1000 on-air bits/event; not transmission of all 100 raw tri-axis samples. Startup, RX, retries, regulation, leakage and memory excluded: a typical-current reference, not a guaranteed node budget.')
 # Resolve original unavailable middle-only exponent labels without inventing values.
 names=['large_o2_r2_middle_c0','damping_middle_opt','large_o1_r1_middle_opt','large_o1_r1_middle_c0','large_o0_r0_middle_opt']
 absent=[]
 for name in names:
  m=next(x for x in manifest if x['name']==name)
  absent.append(dict(name=name,R_nd=m['parameters']['rp']/(m['parameters']['l1']+m['parameters']['l2']),G_nd=m['parameters']['g']/(m['parameters']['Omega']**2*(m['parameters']['l1']+m['parameters']['l2'])),regime='not measured',lyapunov_1_per_s=None,reason='Original output not included in lite attachment; exponent not recomputed. These legacy mountings/topology are outside the corrected comparison.'))
 out['unmeasured_legacy']=absent
 out['historical_turbine_correction']=dict(old_rotor_radius_m=.7,new_rotor_radius_m=56/p.Omega,old_turbine_W=.5*1.225*np.pi*.7**2*8**3*.45,new_turbine_W=.5*1.225*np.pi*(56/p.Omega)**2*8**3*.45,old_fraction=.15180105762287371/(.5*1.225*np.pi*.7**2*8**3*.45),new_fraction=.15180105762287371/(.5*1.225*np.pi*(56/p.Omega)**2*8**3*.45))
 (ROOT/'data/audit.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
if __name__=='__main__':main()
